-- Obfuscation Step: Constants Obfuscator
--
-- Ports the ConstantsObfuscator technique from NewThingsToAdd into the
-- Zuraph pipeline, complementing the existing NumbersToExpressions and
-- EncryptStrings steps.
--
-- What it does:
--   • Numbers  → replaces each number literal N with a setmetatable +
--                power/operator expression that evaluates to N via the
--                identity  x*x - y*y + z = N  (solved randomly each run).
--                A configurable chance also disguises numbers as
--                N + #<mockString> - #<mockString> to defeat trivial
--                constant-folding.
--
--   • Strings  → replaces each string literal with a setmetatable +
--                operator expression that rebuilds the string char-by-char
--                from the same x²-y²+z identity applied to each ASCII
--                byte value.
--
-- Both transforms produce valid Lua 5.1 / LuaU code (no bit32 / ~).
-- The operator used in the metatable (__pow, __mul, __add, etc.) is
-- chosen randomly each call to vary the fingerprint.

local Step     = require("ZukaTech.step")
local Ast      = require("ZukaTech.ast")
local visitast = require("ZukaTech.visitast")

local AstKind  = Ast.AstKind

local ConstantsObfuscator       = Step:extend()
ConstantsObfuscator.Description = "Replaces number and string literals with setmetatable-based algebraic expressions (x²-y²+z identity)."
ConstantsObfuscator.Name        = "Constants Obfuscator"

ConstantsObfuscator.SettingsDescriptor = {
    ObfuscateNumbers = {
        type    = "boolean",
        default = true,
    },
    ObfuscateStrings = {
        type    = "boolean",
        default = true,
    },
    -- 1-in-N chance that a number also gets a mocking-string length disguise
    MockStringChance = {
        type    = "number",
        default = 10,
        min     = 1,
        max     = 100,
    },
    -- Numbers below this absolute value are left as-is (tiny constants)
    MinAbsValue = {
        type    = "number",
        default = 2,
        min     = 0,
        max     = 1e9,
    },
}

-- ── Mocking strings (short, varied) ────────────────────────────────────────
local MOCKING_STRINGS = {
"Zuka was here",
"roblox more like noblox",
"firetouchinterest haha imagine",
"all my homies hate roblox",
}

-- ── Operator table (metamethod name → operator symbol) ─────────────────────
local OPERATORS = {
    { sym = "^",  mm = "__pow"    },
    { sym = "*",  mm = "__mul"    },
    { sym = "/",  mm = "__div"    },
    { sym = "+",  mm = "__add"    },
    { sym = "-",  mm = "__sub"    },
    { sym = "%",  mm = "__mod"    },
    { sym = "..", mm = "__concat" },
}

-- ── Helper: solve x*x - y*y + z = target ───────────────────────────────────
local function solveTriple(target)
    for _ = 1, 1000 do
        local x = math.random(1, 2^16)
        local y = math.random(1, 2^16)
        local z = target - x*x + y*y
        if x*x - y*y + z == target then
            return x, y, z
        end
    end
    return nil
end

-- ── AST helpers (raw table construction — no NodeFactory dependency) ────────
local function numNode(v)
    return { kind = AstKind.NumberExpression, value = v }
end

local function strNode(v)
    return { kind = AstKind.StringExpression, value = v }
end

local function binop(op, l, r)
    return { kind = AstKind.BinaryExpression, operator = op, left = l, right = r }
end

local function unop(op, e)
    return { kind = AstKind.UnaryExpression, operator = op, expression = e }
end

-- Build:  setmetatable({}, { [mm] = function(_, a) return a[1]*a[1]-a[2]*a[2]+a[3] end }) op {x,y,z}
-- Since we can't call NodeFactory we emit a string snippet and parse it.
-- We reuse the pipeline's parser that is already available.
local _parser = nil
local function getParser()
    if not _parser then
        local Parser = require("ZukaTech.parser")
        local Enums  = require("ZukaTech.enums")
        _parser = Parser:new({ LuaVersion = Enums.LuaVersion.Lua51 })
    end
    return _parser
end

local function parseExpr(src)
    local p   = getParser()
    local ok, result = pcall(function()
        return p:parse("return " .. src)
    end)
    if not ok then return nil end
    -- Navigate: body.statements[1].values[1]
    local stmts = result and result.body and result.body.statements
    if stmts and stmts[1] and stmts[1].values then
        return stmts[1].values[1]
    end
    return nil
end

-- ── Number obfuscation ──────────────────────────────────────────────────────
local function obfuscateNumber(value, mockChance, minAbs)
    if math.abs(value) < minAbs then return nil end
    if value ~= math.floor(value) then return nil end  -- floats: skip for safety

    local x, y, z = solveTriple(value)
    if not x then return nil end

    -- Optionally wrap with mocking-string length trick
    local mockLen = 0
    local mockStr = nil
    if math.random(1, mockChance) == 1 and value >= 100 then
        mockStr  = MOCKING_STRINGS[math.random(#MOCKING_STRINGS)]
        mockLen  = #mockStr
    end

    local op  = OPERATORS[math.random(#OPERATORS)]
    -- Build: setmetatable({}, {[mm]=function(_,a) return a[1]*a[1]-a[2]*a[2]+a[3] end}) op {x,y,z}
    local snippet
    if mockStr then
        snippet = string.format(
            [[setmetatable({},{["%s"]=function(_,a)local x,y,z=a[1],a[2],a[3];return x*x-y*y+z end})%s{%d,%d,%d}+%d-#"%s"]],
            op.mm, op.sym, x, y, z + mockLen, mockLen, mockStr
        )
    else
        snippet = string.format(
            [[setmetatable({},{["%s"]=function(_,a)local x,y,z=a[1],a[2],a[3];return x*x-y*y+z end})%s{%d,%d,%d}]],
            op.mm, op.sym, x, y, z
        )
    end
    return parseExpr(snippet)
end

-- ── String obfuscation ──────────────────────────────────────────────────────
local function obfuscateString(value)
    if #value == 0 then return nil end

    local parts = {}
    for i = 1, #value do
        local b = value:byte(i)
        local x, y, z = solveTriple(b)
        if not x then return nil end
        parts[i] = string.format("{%d,%d,%d}", x, y, z)
    end

    local op = OPERATORS[math.random(#OPERATORS)]
    local snippet = string.format(
        [[setmetatable({},{["%s"]=function(_,a)local s=""local i=1 while a[i] do local t=a[i];s=s..string.char(t[1]*t[1]-t[2]*t[2]+t[3]);i=i+1 end return s end})%s{%s}]],
        op.mm, op.sym, table.concat(parts, ",")
    )
    return parseExpr(snippet)
end

-- ── Step interface ──────────────────────────────────────────────────────────

function ConstantsObfuscator:init(settings) end

function ConstantsObfuscator:apply(ast, pipeline)
    local obfNums  = self.ObfuscateNumbers
    local obfStrs  = self.ObfuscateStrings
    local mockCh   = self.MockStringChance
    local minAbs   = self.MinAbsValue

    visitast(ast, function(node, data)
        if obfNums and node.kind == AstKind.NumberExpression then
            local replacement = obfuscateNumber(node.value, mockCh, minAbs)
            if replacement then
                -- Copy replacement fields into the node in-place
                for k in pairs(node) do node[k] = nil end
                for k, v in pairs(replacement) do node[k] = v end
            end

        elseif obfStrs and node.kind == AstKind.StringExpression then
            -- Don't obfuscate very short or whitespace-only strings
            if #node.value >= 2 then
                local replacement = obfuscateString(node.value)
                if replacement then
                    for k in pairs(node) do node[k] = nil end
                    for k, v in pairs(replacement) do node[k] = v end
                end
            end
        end
    end)

    return ast
end

return ConstantsObfuscator
