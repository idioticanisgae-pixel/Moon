return (function(...)
local QueueCycle, QueueControllerModule;
do
	local QueueTrackerHandler = math.floor;
	local QueueListener = math.random;
	local QueueBuilderStage = table.remove;
	local QueueAdapterController = string.char;
	local QueueValidator = string.byte;
	local QueueStage = string.len;
	local bbsnenIvbdWodL = math.floor;
	local lxrdhMqgMa = 0x19660D;
	local _0xE0B1_0x80BD = 0x13157;
	local QueueSchedulerInterface = 4294967296;
	local QueueCollector = 0x71;
	local function QueueStore(i36, s37)
		local t38, k39 = 0x0, 0x1;
		while i36 > 0x0 or s37 > 0x0 do
			local k37 = i36 % 0x2;
			local s38 = s37 % 0x2;
			if k37 ~= s38 then
				t38 = t38 + k39;
			end;
			i36 = bbsnenIvbdWodL(i36 / 0x2);
			s37 = bbsnenIvbdWodL(s37 / 0x2);
			k39 = k39 * 0x2;
		end;
		return t38;
	end;
	local QueueScheduler, QueueExecutorSlot, QueueSchedulerMap = 0x0, 0x1, {};
	local QueueConnectorRoot = {};
	local QueueRouterLeaf = {};
	for s39 = 0x1, 0x100, 0x1 do
		QueueRouterLeaf[s39] = s39;
	end;
	repeat
		local p40 = QueueListener(0x1, #QueueRouterLeaf);
		local s41 = QueueBuilderStage(QueueRouterLeaf, p40);
		QueueConnectorRoot[s41] = QueueAdapterController(s41 - 0x1);
	until #QueueRouterLeaf == 0x0;
	local function QueueEncoderModule()
		QueueScheduler = (QueueScheduler * lxrdhMqgMa + _0xE0B1_0x80BD) % QueueSchedulerInterface;
		QueueExecutorSlot = (QueueExecutorSlot * 0x25 + 0x7) % 0xFB + 0x1;
		return QueueTrackerHandler((QueueScheduler + QueueExecutorSlot * 0x10001) % QueueSchedulerInterface);
	end;
	local function QueueCollectorMap()
		if #QueueSchedulerMap == 0x0 then
			local c41 = QueueEncoderModule();
			QueueSchedulerMap = {
					c41 % 0x100,
					QueueTrackerHandler(c41 / 0x100) % 0x100,
					QueueTrackerHandler(c41 / 0x10000) % 0x100,
					QueueTrackerHandler(c41 / 0x1000000) % 0x100,
				};
		end;
		return QueueBuilderStage(QueueSchedulerMap);
	end;
	local QueueManagerController = {};
	local function QueueRouterHelper(v42, s43)
		if not QueueManagerController[s43] then
			QueueSchedulerMap = {};
			QueueScheduler = s43 % QueueSchedulerInterface;
			QueueExecutorSlot = s43 % 0xFB + 0x1;
			local p43 = QueueStage(v42);
			local s44 = QueueCollector;
			local t45 = {};
			for v44 = 0x1, p43, 0x1 do
				local s45 = QueueValidator(v42, v44);
				local t46 = QueueCollectorMap();
				local k47 = QueueStore(s45, QueueStore(t46, s44)) % 0x100;
				t45[v44] = QueueConnectorRoot[k47 + 0x1];
				s44 = ((s44 + k47) + 0x1F) % 0x100;
			end;
			QueueManagerController[s43] = table.concat(t45);
		end;
		return s43;
	end;
	QueueControllerModule = setmetatable({}, { __index = function(k46, s47)
				return QueueManagerController[s47];
			end, __metatable = nil });
	function QueueCycle(p47, s48)
		return QueueRouterHelper(p47, s48);
	end;
end;
if (getgenv())[QueueControllerModule[QueueCycle("!\015\191\198R\218\160\188\127\150\142\188hht", -1005680611)]] then
	return;
end;
(getgenv())[QueueControllerModule[QueueCycle("\232\179\191\240\151x\135\205\202n\241\248.\239b", -1130596040)]] = true;
local QueueBuilderList = newcclosure or function(QueueEmitterNode)
		return QueueEmitterNode;
	end;
local QueueSlot = checkcaller or function()
		return false;
	end;
local QueueUtil = getrawmetatable;
local QueueParserSystem = setreadonly or function()
 
	end;
local QueueHandler = hookfunction or function()
 
	end;
local QueueInitializer = getgc or get_gc_objects or function()
		return {};
	end;
local rnGnXMUJax = getscriptidentity or getidentity or get_thread_identity or nil;
local qzUnoTOuT = setscriptidentity or setidentity or set_thread_identity or nil;
if not game:IsLoaded() then
	game[QueueControllerModule[QueueCycle("\177\217D\187\163\158", -2063791622)]]:Wait();
end;
local _0x82E1_0xEEED = game:GetService(QueueControllerModule[QueueCycle("-\199\203\230\012K\159", -628443883)]);
repeat
	task[QueueControllerModule[QueueCycle("QHXn", -1083736370)]](.1);
until _0x82E1_0xEEED and _0x82E1_0xEEED[QueueControllerModule[QueueCycle("\' \197a\237\174_\"\157\178\012", -879323347)]];
local QueueBase = _0x82E1_0xEEED[QueueControllerModule[QueueCycle("\216\246\002\227\244=X\209\226\235\176", -188552827)]];
local QueueManager = false;
local QueueRouter = nil;
local QueueTracker = {};
local QueueBinder = {
		[QueueControllerModule[QueueCycle("\133!\253<)-\137\209 #\147\251", -706106413)]] = 0x0,
		[QueueControllerModule[QueueCycle("\244\180\139\176\230\165,#\206\015\150J\198\221", -1962666488)]] = 0x0,
		[QueueControllerModule[QueueCycle("\214\1310\149\243\128\1947ws\r\215\176W\130)", -699355999)]] = 0x0,
		[QueueControllerModule[QueueCycle("\021\220\016\182\207\168\215\186\195.Z\215|Ui", -1750782134)]] = 0x0,
		[QueueControllerModule[QueueCycle("\028\173\r[A\173\255\189\202\230BJ(\253 O\2353\176", -2133917282)]] = 0x0,
		[QueueControllerModule[QueueCycle("/\001\137\028\146\173X9\225\028%\026", -1184533814)]] = 0x0,
	};
local QueueService = {
		[QueueControllerModule[QueueCycle("q\137M}\152s\129Bn=\243", -2135359118)]] = true,
		[QueueControllerModule[QueueCycle("\166\028n%\159{\005\212D6\173", -1350017264)]] = true,
		[QueueControllerModule[QueueCycle("\193uH", -863463151)]] = true,
		[QueueControllerModule[QueueCycle("\138\007\173\009B\223", -1848499292)]] = true,
		[QueueControllerModule[QueueCycle("J\001&\218", -479738161)]] = true,
		[QueueControllerModule[QueueCycle("\134\255f2@\231", -413413705)]] = true,
		[QueueControllerModule[QueueCycle("?e\227\205\254a\210\192", -1707789206)]] = true,
		[QueueControllerModule[QueueCycle("8f\202\153\146+U\169f\217\186\194\026\031", -1961290190)]] = true,
		[QueueControllerModule[QueueCycle("LprB1\154<u%.\212\189\207=\178\201", -1956505916)]] = true,
	};
local QueueManagerUtil = { [QueueControllerModule[QueueCycle("|\'p\209\137\003\201\191", -2085157010)]] = true, [QueueControllerModule[QueueCycle("\012w\133\195\159\239\000U^\0193T", -1728630290)]] = true };
local QueueResolverPort = {
		[QueueControllerModule[QueueCycle("\127\'\159\187", -519454189)]] = true,
		[QueueControllerModule[QueueCycle("\000\1619\153UDol{P", -1448193188)]] = true,
		[QueueControllerModule[QueueCycle("\145b\196:\143\136\132\016\172\008\199j", -2076243842)]] = true,
		[QueueControllerModule[QueueCycle("\030\'DX=\230\007Z\199\136O", -774134857)]] = true,
		[QueueControllerModule[QueueCycle("\165%pu7\168\221\250\203!\221\236\173\203", -1599258278)]] = true,
		[QueueControllerModule[QueueCycle("X\000\219\212*\131x\157+h~}\001(", -560284363)]] = true,
		[QueueControllerModule[QueueCycle("\246\027\200]\133\198L{\250\246\242\136\197\220\147\197\212\198J\006\152", -239606929)]] = true,
		[QueueControllerModule[QueueCycle("=\181\005\167W\241\181\145\142}q\242\025\191\142\016\230\"\250\000r\186", -1383900410)]] = true,
	};
local QueueController = {
		[QueueControllerModule[QueueCycle("\193[;t:\027c", -951546223)]] = true,
		[QueueControllerModule[QueueCycle("\183\210\'\167\205\201\240\175c)\139`\127XR", -859072105)]] = true,
		[QueueControllerModule[QueueCycle("\217~\184\133", -723473983)]] = true,
		[QueueControllerModule[QueueCycle("d\nve", -6684877)]] = true,
		[QueueControllerModule[QueueCycle("X\252\134B\213i1\r\r\143", -803954647)]] = true,
	};
local QueuePhase = {
		[QueueControllerModule[QueueCycle("YCd|D\167\209=-\219z", -536494069)]] = true,
		[QueueControllerModule[QueueCycle("\217t\234\174\212\193\222\210?z\241\022\229\153", -1843846094)]] = true,
		[QueueControllerModule[QueueCycle("\008\025U\162\218@\158\228\144;q\196", -470562841)]] = true,
		[QueueControllerModule[QueueCycle("\223\163%\023\152\015\179\165j\005\011d0\255\251", -860317327)]] = true,
		[QueueControllerModule[QueueCycle("G\\\162\197&\2331LwL", -205527169)]] = true,
		[QueueControllerModule[QueueCycle("D\152%\152ou\182\136\129D", -1514779796)]] = true,
		[QueueControllerModule[QueueCycle("N%\031f\179\129I\148\152", -108727543)]] = true,
	};
local QueueImpl = {
		QueueControllerModule[QueueCycle("\173n \215v\203\019\009f", -460469989)],
		QueueControllerModule[QueueCycle("\179u^\021\225\214\198\224\228;", -983266615)],
		QueueControllerModule[QueueCycle("&\'\137`\204\140\009\140 \162", -48367045)],
		QueueControllerModule[QueueCycle("\217\224\230A\011\231\028{\201", -955675117)],
		QueueControllerModule[QueueCycle("q\135\212,\020\008!\154^\133\210;\153", -695161567)],
		QueueControllerModule[QueueCycle("\200\018\2145\142\012\031\'\216U\139\016", -563495725)],
		QueueControllerModule[QueueCycle("@\219\171\220\247\233\128\237\209|", -391786165)],
	};
local QueueAllocator = {
		QueueControllerModule[QueueCycle("\020\008\163\211[$", -714102049)],
		QueueControllerModule[QueueCycle("\165\1881M", -635063221)],
		QueueControllerModule[QueueCycle("\015\194\250F\137", -502086619)],
		QueueControllerModule[QueueCycle("\241\000\144g\230\157y", -500317093)],
		QueueControllerModule[QueueCycle("`\154Tj", -872048629)],
		QueueControllerModule[QueueCycle("\199\167\154\189\003c\004\220", -91097821)],
		QueueControllerModule[QueueCycle("N\160\197", -352070137)],
	};
local QueueParserModule = { [QueueControllerModule[QueueCycle("\231\018X\225\225\174\031\216\215\162o", -1535227652)]] = true, [QueueControllerModule[QueueCycle("\146\175>\230\208nvVz\152", -1704577844)]] = true };
local QueueStoreBase = {
		{ QueueControllerModule[QueueCycle("C\004[\144v\209!\137", -919301527)], true, 0x1 },
		{ QueueControllerModule[QueueCycle("\007\141\242\253\1504\'\157\253\2477\252", -460732141)], true, 0x1 },
		{ QueueControllerModule[QueueCycle("\221\136\203\146\140Gf\176N\163\029\232h!9", -815685949)], true, 0x1 },
		{ QueueControllerModule[QueueCycle("\242/\2274\226\234\167\023,\128b\148\232", -64686007)], false, 0x1 },
		{ QueueControllerModule[QueueCycle("\154\250\130\130\135\1283\156\137E\021q\133\191|", -2104949486)], false, 0x1 },
		{ QueueControllerModule[QueueCycle("\023\161\235\208\138\214\139\186\162\029_\152Y0\148\017\158\176", -1952114870)], false, 0x1 },
		{ QueueControllerModule[QueueCycle("\007\011A\252\197W\173\191\248\"\2287\244\242", -1803605762)], true, .5 },
		{ QueueControllerModule[QueueCycle("o\127\'\000\174\127\235D\1619q\245\207|", -499923865)], true, .5 },
		{ QueueControllerModule[QueueCycle("4CW}\192\253\1733\214<\144\215?\143P\019", -2116222022)], false, 0x1 },
		{ QueueControllerModule[QueueCycle(")\144\201\'\146\138\132\219_", -2082732104)], true, .5 },
	};
local QueueParserHeap = 0x3;
local QueueWrapperHelper = 0x2;
local function QueueGate(QueueStorePhase, ...)
	local QueueManagerService, QueueHeap = pcall(QueueStorePhase, ...);
	if QueueManagerService then
		return QueueHeap;
	end;
end;
local function QueueSystem(QueuePass, QueueAllocatorPass)
	local QueueAdapter = QueueUtil(QueuePass);
	if not QueueAdapter then
		return false;
	end;
	local QueueStateStep = pcall(function()
			QueueParserSystem(QueueAdapter, false);
			QueueAllocatorPass(QueueAdapter);
			QueueParserSystem(QueueAdapter, true);
		end);
	if not QueueStateStep then
		pcall(QueueParserSystem, QueueAdapter, true);
	end;
	return QueueStateStep;
end;
local function QueueFrame(QueueState, QueueParser)
	if type(QueueState) ~= QueueControllerModule[QueueCycle("\174\147\187\007\223\243;U", -1459924490)] then
		return false;
	end;
	local QueueInterface = pcall(QueueHandler, QueueState, QueueBuilderList(QueueParser));
	if not QueueInterface then
		return false;
	end;
	table[QueueControllerModule[QueueCycle("\222\007\209\1891\020", -1910825930)]](QueueTracker, QueueState);
	QueueBinder[QueueControllerModule[QueueCycle("\131\139\252xt|lh\182\204VZ\167\226?", -1613676638)]] += 0x1;
	return true;
end;
local function QueueProviderHandler(QueueManagerHelper)
	for r1, s2 in ipairs(QueueTracker) do
		if QueueManagerHelper == s2 then
			return true;
		end;
	end;
	return false;
end;
local function QueueExecutor(QueueListenerNode)
	if type(QueueListenerNode) ~= QueueControllerModule[QueueCycle("\132\0031(\019", -1413523586)] then
		return;
	end;
	pcall(function()
		QueueParserSystem(QueueListenerNode, false);
		local p2 = QueueUtil(QueueListenerNode);
		if p2 then
			pcall(QueueParserSystem, p2, false);
		end;
	end);
end;
for QueueHelper, QueueAdapterBase in ipairs({ getgenv, getrenv, getreg }) do
	if type(QueueAdapterBase) == QueueControllerModule[QueueCycle("+\019g01\149\177s", -137302111)] then
		local c3, s4 = pcall(QueueAdapterBase);
		if c3 and type(s4) == QueueControllerModule[QueueCycle("\207[$\227\230", -354626119)] then
			QueueExecutor(s4);
		end;
	end;
end;
local function _0x8625_0x7509_0x4304_0x06C2(QueueResolver)
	if type(QueueResolver) ~= QueueControllerModule[QueueCycle("\029\171\238;\159", -678318301)] then
		return 0x0;
	end;
	local QueueDispatcherHook = 0x0;
	pcall(function()
		for j4, s5 in ipairs(QueueStoreBase) do
			local t6, k7, n8 = s5[0x1], s5[0x2], s5[0x3];
			local j9 = rawget(QueueResolver, t6);
			if j9 ~= nil then
				if k7 then
					if type(j9) == QueueControllerModule[QueueCycle("\166\027\029\128\162\155\205\182", -1656997256)] then
						QueueDispatcherHook += n8;
					end;
				else
					QueueDispatcherHook += n8;
				end;
			end;
		end;
	end);
	return QueueDispatcherHook;
end;
local function nGScHLaeNdYns()
	local QueueStep;
	local QueueMap = pcall(function()
			QueueStep = QueueInitializer(true);
		end);
	if not QueueMap or not QueueStep then
		return nil;
	end;
	for p5, s6 in ipairs(QueueStep) do
		local t7, k8 = pcall(function()
				return type(s6) == QueueControllerModule[QueueCycle("I\234\2457h", -789863977)];
			end);
		if t7 and (k8 and _0x8625_0x7509_0x4304_0x06C2(s6) >= QueueParserHeap) then
			return s6;
		end;
	end;
	return nil;
end;
local function mnbtWSEyFOzi(QueueSource)
	if not QueueSource then
		return;
	end;
	if type(QueueSource[QueueControllerModule[QueueCycle("p4\249r\232\214I\195", -274800835)]]) == QueueControllerModule[QueueCycle("|\179\193\026\164\211\217\'", -825123421)] then
		QueueFrame(QueueSource[QueueControllerModule[QueueCycle("A\138\240$_\132\220\229", -2052977852)]], function(...)
			QueueBinder[QueueControllerModule[QueueCycle("\188\160\172_C\167\r\139\186,k\235\247`\224\028", -1861803506)]] += 0x1;
		end);
	end;
	if type(QueueSource[QueueControllerModule[QueueCycle("`7.\183n\015\254\214W\242\007;", -1742720960)]]) == QueueControllerModule[QueueCycle("\232\134?\247\207\201/L", -1668597482)] then
		QueueFrame(QueueSource[QueueControllerModule[QueueCycle("L\130q\171\011\215\247(r\234Zs", -1049263381)]], function(...)
			QueueBinder[QueueControllerModule[QueueCycle("O\011c/\239\217\177\2513u\232q", -28640107)]] += 0x1;
		end);
	end;
	if type(QueueSource[QueueControllerModule[QueueCycle("\172}DZ\172\175\200\195_~\157\020\225\011&", -1092715076)]]) == QueueControllerModule[QueueCycle("(\0080\001\165\244\158\165", -361114381)] then
		QueueFrame(QueueSource[QueueControllerModule[QueueCycle("_\165\017J\236\170\2349iI^Y\150l\251", -403255315)]], function(...)
			QueueBinder[QueueControllerModule[QueueCycle("\2515\026}\251\161:\238e\009\184Z\197\027\139\229\217dN", -710694073)]] += 0x1;
		end);
	end;
	if type(QueueSource[QueueControllerModule[QueueCycle("b\128\031v\161\169\184\184H\196Cw\026\022", -452998657)]]) == QueueControllerModule[QueueCycle("\192\024r4U\134\162\019", -850158937)] then
		QueueFrame(QueueSource[QueueControllerModule[QueueCycle("\150\186\131\149r\028\151\253\182xQ\212\015\148", -1301256992)]], function(...)
			return nil;
		end);
	end;
	if type(QueueSource[QueueControllerModule[QueueCycle("bY\217\021\240\139z_\164\177\031\011\r\022", -991852093)]]) == QueueControllerModule[QueueCycle("\025MNl\220,1\028", -1274779640)] then
		QueueFrame(QueueSource[QueueControllerModule[QueueCycle(">\157i\193\188\031\009Khz\227d%\209", -272048239)]], function(...)
 
		end);
	end;
	if type(QueueSource[QueueControllerModule[QueueCycle("\215n\224}\001\141\166\211qr\187\224d", -347875705)]]) == QueueControllerModule[QueueCycle("\004k6\015\001", -846030043)] then
		local c6 = getmetatable(QueueSource[QueueControllerModule[QueueCycle("\127\138\171\205x\129jj?\253py\216", -986609053)]]) or {};
		rawset(c6, QueueControllerModule[QueueCycle("\230\1596\199\007\151\139", -331491205)], function()
			return false;
		end);
		rawset(c6, QueueControllerModule[QueueCycle("\012\241\214>\019z\142L\185\026", -793665181)], function()
 
		end);
		rawset(c6, QueueControllerModule[QueueCycle("\145x\173(\019", -861824701)], function()
			return 0x0;
		end);
		pcall(setmetatable, QueueSource[QueueControllerModule[QueueCycle("\246\211{\152\160\005\159n3}`\204%", -88476301)]], c6);
	end;
	if type(QueueSource[QueueControllerModule[QueueCycle("&i\177\2229\154L\n\012\136h\158\156\209\191", -246947185)]]) == QueueControllerModule[QueueCycle("\148\146\2369A", -1754648876)] then
		local k9 = {};
		rawset(k9, QueueControllerModule[QueueCycle("<M\1516\209\127\143", -1565702822)], function(n10, s11)
			return { {
					[QueueControllerModule[QueueCycle("\163 ", -156439207)]] = s11,
					[QueueControllerModule[QueueCycle("\012\189s&\237\193\211\211", -1930946096)]] = QueueBase[QueueControllerModule[QueueCycle("\145\166\206\\", -120000079)]],
					[QueueControllerModule[QueueCycle("N\190X*I\001\247\132&\019\250", -1188400556)]] = QueueBase[QueueControllerModule[QueueCycle(":\230\138k>\235\002\241\233\193[", -73337023)]],
					[QueueControllerModule[QueueCycle("\251\184\161\018w\159", -1165200104)]] = QueueBase[QueueControllerModule[QueueCycle("\241\1828\017\173{", -114560425)]],
				} };
		end);
		rawset(k9, QueueControllerModule[QueueCycle("\030X\202\161\136vOB^a", -533086093)], function()
 
		end);
		pcall(setmetatable, QueueSource[QueueControllerModule[QueueCycle("C\185\168Eea\014u\174\1389\253\137X\192", -1021213117)]], k9);
	end;
	if QueueSource[QueueControllerModule[QueueCycle("\1390T\200\179\132E\207\'\146I\029\205U\154\160\024\152", -1883103356)]] ~= nil then
		pcall(function()
			QueueSource[QueueControllerModule[QueueCycle("\153\222\142o\015\245\220\235\171\162\151\020\127o\144EV\147", -786193849)]] = math[QueueControllerModule[QueueCycle("\176\178\234\023", -1052343667)]];
		end);
	end;
	if QueueSource[QueueControllerModule[QueueCycle("X\186\127\011\234,*.?5\1659\164^\189%", -1780929614)]] ~= nil then
		pcall(function()
			QueueSource[QueueControllerModule[QueueCycle("\179\018 =ZW?|\134\212a\133\146\174f0", -1548073100)]] = false;
		end);
	end;
end;
local function QueueBuilder()
	local QueueSchedulerHeap = tostring(QueueBase[QueueControllerModule[QueueCycle("\158\211\254\131\217\170", -1482731714)]]);
	local QueueInvokerCycle;
	local QueueInvokerSystem = pcall(function()
			QueueInvokerCycle = QueueInitializer(true);
		end);
	if not QueueInvokerSystem or not QueueInvokerCycle then
		return;
	end;
	for i11, s12 in ipairs(QueueInvokerCycle) do
		local t13, k14 = pcall(function()
				return type(s12) == QueueControllerModule[QueueCycle("\175\2558\218\221", -496581427)];
			end);
		if not (t13 and k14) then
			continue;
		end;
		local n15, j16, xrJoeiNe = pcall(function()
				return rawget(s12, QueueSchedulerHeap), rawget(s12, QueueControllerModule[QueueCycle("5\012\133\227\020/", -1317117188)]);
			end);
		if not (n15 and type(j16) == QueueControllerModule[QueueCycle("A%\187D\199", -1920918782)]) then
			continue;
		end;
		local lzsFmtaC, _0x0C78_0x4838_0xA8AD_0x9FF1 = pcall(function()
				return rawget(j16, QueueControllerModule[QueueCycle("\149@\234\208\161\248\219\201\248\164", -2031612464)]) ~= nil;
			end);
		if lzsFmtaC and (_0x0C78_0x4838_0xA8AD_0x9FF1 and xrJoeiNe ~= nil) then
			task[QueueControllerModule[QueueCycle("pY\136->", -160568101)]](function()
				while not QueueManager do
					task[QueueControllerModule[QueueCycle("\194\154\178?", -931229443)]](0x8);
					pcall(function()
						local QueueConfig = s12[QueueSchedulerHeap];
						if QueueConfig then
							QueueConfig[QueueControllerModule[QueueCycle("\210q\148*\006\128D\141\203\r", -1795282436)]] = os[QueueControllerModule[QueueCycle("4\218K\201", -1178766470)]]();
							QueueConfig[QueueControllerModule[QueueCycle("\168\019\2372Y\002\236\133T.=\176", -170726491)]] = true;
						end;
					end);
				end;
			end);
		end;
	end;
end;
local function QueueSink()
	local QueueStoreStage = getnamecallmethod;
	QueueSystem(game, function(v12)
		local s13 = v12[QueueControllerModule[QueueCycle("\219\233uP\205;\185A]\210", -1486139690)]];
		v12[QueueControllerModule[QueueCycle("\225\208\1836\161\174\167\205 \147", -223681195)]] = QueueBuilderList(function(c13, ...)
				if QueueSlot() then
					return s13(c13, ...);
				end;
				local s14 = QueueStoreStage();
				if rawget(QueueController, s14) then
					return s13(c13, ...);
				end;
				if not rawget(QueueResolverPort, s14) then
					return s13(c13, ...);
				end;
				if s14 == QueueControllerModule[QueueCycle("\199\176O\169", -65144773)] and c13 == QueueBase then
					local v14 = (tostring(... or QueueControllerModule[QueueCycle("", -1136494460)])):lower();
					for QueueValidatorSet = 0x1, #QueueAllocator, 0x1 do
						if v14:find(QueueAllocator[QueueValidatorSet], 0x1, true) then
							QueueBinder[QueueControllerModule[QueueCycle(">`gL\152\000[\2120\207\015\200", -869820337)]] += 0x1;
							return nil;
						end;
					end;
				end;
				if s14 == QueueControllerModule[QueueCycle("\137G\143\004\252\221$+GA", -1173261278)] or s14 == QueueControllerModule[QueueCycle(".^\233\173\018\202\003\005I\164\222X", -1411950674)] then
					local r15;
					local s16 = pcall(function()
							r15 = c13[QueueControllerModule[QueueCycle("\238\004k\237", -1492890104)]];
						end);
					if s16 and rawget(QueuePhase, r15) then
						QueueBinder[QueueControllerModule[QueueCycle("\012\1793R\224G\nO%\r\138<\146\024", -87100003)]] += 0x1;
						if s14 == QueueControllerModule[QueueCycle("\195G\214=\019\168\180]\025[_\158", -888367591)] then
							return QueueControllerModule[QueueCycle("mJ-\207", -455947867)];
						end;
						return nil;
					end;
					QueueBinder[QueueControllerModule[QueueCycle("\185\167Z\235\031\008E5\228\009\217X", -267198427)]] += 0x1;
				end;
				if s14 == QueueControllerModule[QueueCycle("\168s\007\"\171\202\214\208t\187\163", -1670956850)] or s14 == QueueControllerModule[QueueCycle("\192G\n\232.\186\189QT\021-\155\030\128", -440743051)] then
					local p16 = s13(c13, ...);
					if type(p16) ~= QueueControllerModule[QueueCycle("\225\154\000\155\163", -1256429000)] then
						return p16;
					end;
					local s17 = false;
					for QueueCollectorSlot = 0x1, #p16, 0x1 do
						local queue_object, queue_instance_wrapper = pcall(function()
								return p16[QueueCollectorSlot][QueueControllerModule[QueueCycle("\254T\221\r", -1041005593)]];
							end);
						if queue_object and rawget(QueueParserModule, queue_instance_wrapper) then
							s17 = true;
							break;
						end;
					end;
					if not s17 then
						return p16;
					end;
					local t18, k19 = {}, 0x0;
					for QueueConfigHelper = 0x1, #p16, 0x1 do
						local queue_router_impl, queue_module = pcall(function()
								return p16[QueueConfigHelper][QueueControllerModule[QueueCycle("nnJ+", -213260653)]];
							end);
						if not (queue_router_impl and rawget(QueueParserModule, queue_module)) then
							k19 = k19 + 0x1;
							t18[k19] = p16[QueueConfigHelper];
						end;
					end;
					return t18;
				end;
				if s14 == QueueControllerModule[QueueCycle("A7\254\215|\028N]\161:\164\030JF", -1119651194)] or s14 == QueueControllerModule[QueueCycle("\217\193\230\237\190P\031\240\212\172\201\\\219\212\234\255\164F\022\225z", -726423193)] or s14 == QueueControllerModule[QueueCycle("Q\156\233\146\016pH\166H\1664\251S\141Ly\156\166R\177\179\001", -1067810635)] then
					if rawget(QueueParserModule, tostring(... or QueueControllerModule[QueueCycle("", -246488419)])) then
						return nil;
					end;
				end;
				return s13(c13, ...);
			end);
	end);
end;
local function QueueBuilderBase()
	QueueSystem(game, function(i17)
		local s18 = i17[QueueControllerModule[QueueCycle("\131.\187\249\165\195p", -1521792362)]];
		local t19 = i17[QueueControllerModule[QueueCycle("\169\007\r\239\007\r\134*\018\143", -1927931348)]];
		i17[QueueControllerModule[QueueCycle("T\218\137\175\001Co", -2122382594)]] = QueueBuilderList(function(v18, s19, ...)
				if QueueSlot() then
					return s18(v18, s19, ...);
				end;
				if type(s19) == QueueControllerModule[QueueCycle("\026EJ`\254(", -1145473166)] and rawget(QueueService, s19) then
					return nil;
				end;
				return s18(v18, s19, ...);
			end);
		i17[QueueControllerModule[QueueCycle("\194V\132\143\018{\139\221b\244", -1237881746)]] = QueueBuilderList(function(k20, s21, t22, ...)
				if QueueSlot() then
					if t19 then
						return t19(k20, s21, t22, ...);
					end;
					return rawset(k20, s21, t22);
				end;
				if rawget(QueueManagerUtil, s21) then
					return;
				end;
				if t19 then
					pcall(t19, k20, s21, t22, ...);
				else
					pcall(rawset, k20, s21, t22);
				end;
			end);
	end);
	local QueueBridge = QueueGate(function()
			return game:GetService(QueueControllerModule[QueueCycle("\nW\131H\167^\018\023\147", -1131841262)]);
		end);
	if QueueBridge and QueueUtil(QueueBridge) ~= QueueUtil(game) then
		QueueSystem(QueueBridge, function(c21)
			local s22 = c21[QueueControllerModule[QueueCycle("\177\230\183q\166\184Q", -1270912898)]];
			c21[QueueControllerModule[QueueCycle("\149\205hO\178\019\148", -1461235250)]] = QueueBuilderList(function(p22, s23, ...)
					if QueueSlot() then
						return s22(p22, s23, ...);
					end;
					if type(s23) == QueueControllerModule[QueueCycle("\022FQ\028m)", -2078144444)] and rawget(QueueService, s23) then
						return nil;
					end;
					return s22(p22, s23, ...);
				end);
		end);
	end;
end;
local function QueueProvider()
	if not rnGnXMUJax then
		return;
	end;
	pcall(QueueHandler, rnGnXMUJax, QueueBuilderList(function(...)
		if QueueSlot() then
			return rnGnXMUJax(...);
		end;
		return QueueWrapperHelper;
	end));
	if qzUnoTOuT then
		pcall(QueueHandler, qzUnoTOuT, QueueBuilderList(function(v23, ...)
			if QueueSlot() then
				return qzUnoTOuT(v23, ...);
			end;
		end));
	end;
	for p24, s25 in ipairs({ QueueControllerModule[QueueCycle("\240\239\219L\139\165\252\173]\235\141", -1591000490)], QueueControllerModule[QueueCycle("\211V\022\127\247\157\133M)@j\223\233q\181VuZE", -285876757)], QueueControllerModule[QueueCycle("\166X\023\003ZC\185K\234<\243B\202p\155\027\193", -1011316879)] }) do
		local t26 = rawget(getgenv(), s25) or rawget(getrenv(), s25);
		if t26 and (t26 ~= rnGnXMUJax and type(t26) == QueueControllerModule[QueueCycle("\213\141\004m\150\181\180\208", -996374215)]) then
			pcall(QueueHandler, t26, QueueBuilderList(function(...)
				if QueueSlot() then
					return t26(...);
				end;
				return QueueWrapperHelper;
			end));
		end;
	end;
end;
local function QueueStoreService()
	local function QueueLeaf(n25, s26)
		if type(n25) ~= QueueControllerModule[QueueCycle("\187=\196\244v\146\016f", -675762319)] then
			return;
		end;
		pcall(QueueHandler, n25, QueueBuilderList(function(r26, ...)
			if QueueProviderHandler(r26) then
				return s26;
			end;
			return n25(r26, ...);
		end));
	end;
	QueueLeaf(debug[QueueControllerModule[QueueCycle("\237o\208p", -485046739)]] or debug[QueueControllerModule[QueueCycle("\210\001\179\151\235\131\132", -1598406284)]], nil);
	QueueLeaf(debug[QueueControllerModule[QueueCycle("60n\184\176H\251\207\242\192\248", -14090671)]], {});
	QueueLeaf(debug[QueueControllerModule[QueueCycle("\249g\015\253\027Pa\127\196", -1172409284)]], {});
	QueueLeaf(debug[QueueControllerModule[QueueCycle("w\173G\023\154\233n\183\168C,\127", -242293987)]], {});
end;
local function QueueBridgeGate()
	local QueueSchedulerSystem = QueueBase[QueueControllerModule[QueueCycle("%\220\166\238", -1860558284)]];
	QueueFrame(QueueSchedulerSystem, function(j27, s28, ...)
		if QueueSlot() then
			return QueueSchedulerSystem(j27, s28, ...);
		end;
		if j27 == QueueBase then
			local j28 = (tostring(s28 or QueueControllerModule[QueueCycle("", -1535948570)])):lower();
			for n29, s30 in ipairs(QueueAllocator) do
				if j28:find(s30, 0x1, true) then
					QueueBinder[QueueControllerModule[QueueCycle("\239\147\251B\191\212\227sh\209B\209", -1983835262)]] += 0x1;
					return nil;
				end;
			end;
		end;
		return QueueSchedulerSystem(j27, s28, ...);
	end);
end;
local QueueHandlerSet;
QueueHandlerSet = QueueHandler((getrenv())[QueueControllerModule[QueueCycle("\015\173\203hQV\132", -606292039)]], QueueBuilderList(function(QueueHook)
		if QueueSlot() then
			return QueueHandlerSet(QueueHook);
		end;
		if typeof(QueueHook) == QueueControllerModule[QueueCycle("\141\219h\0041\015\002\197", -11862379)] then
			local r30 = QueueHook[QueueControllerModule[QueueCycle("\1606]5", -1470934874)]]:lower();
			if r30:find(QueueControllerModule[QueueCycle("\008\165\183\134\222\137", -1853021414)], 0x1, true) or r30:find(QueueControllerModule[QueueCycle("\213\165Ps", -1913775140)], 0x1, true) or r30:find(QueueControllerModule[QueueCycle("\242\173x\127\170o", -2123300126)], 0x1, true) then
				return setmetatable({}, { [QueueControllerModule[QueueCycle("C\031\213w\019f>", -91818739)]] = function()
						return function()
 
						end;
					end, [QueueControllerModule[QueueCycle("\165!.\208\240\229_J\241\020", -1128498824)]] = function()
 
					end, [QueueControllerModule[QueueCycle("\186\249O\008[\192", -308880595)]] = function()
						return {};
					end });
			end;
		end;
		return QueueHandlerSet(QueueHook);
	end));
local function QueueBuilderController()
	local function QueueConnectorHandler(p31)
		if typeof(p31) ~= QueueControllerModule[QueueCycle("6*C\139?R\130\1654-\179", -98110387)] and typeof(p31) ~= QueueControllerModule[QueueCycle("\148(ZZf\031\207\241^\161\027\232\253\133", -680349979)] then
			return;
		end;
		local s32, t33 = pcall(function()
				return p31[QueueControllerModule[QueueCycle("\\\207l\194", -710431921)]];
			end);
		if not s32 then
			return;
		end;
		local k34 = t33:lower();
		for v32, s33 in ipairs(QueueImpl) do
			if k34:find(s33, 0x1, true) then
				rawset(QueuePhase, t33, true);
				break;
			end;
		end;
	end;
	pcall(function()
		for k33, s34 in ipairs(game:GetDescendants()) do
			QueueConnectorHandler(s34);
		end;
	end);
	pcall(function()
		game[QueueControllerModule[QueueCycle("\1539\195\181\204}\166\003\139g\011%\171\182\232", -74713321)]]:Connect(function(t34)
			task[QueueControllerModule[QueueCycle("\201w\146\156\020", -1074954278)]](QueueConnectorHandler, t34);
		end);
	end);
end;
local function QueueRoot()
	local QueueWrapper = nGScHLaeNdYns();
	if QueueWrapper and QueueWrapper ~= QueueRouter then
		QueueRouter = QueueWrapper;
		mnbtWSEyFOzi(QueueWrapper);
		warn(QueueControllerModule[QueueCycle("\222U+\178J\141\245\176\135\028\230T\005\135\191-\144R4\127{\155n\143\132a\166\204B\172J\217\236\172^uA4\176g\245\231\132\226", -907242535)]);
	end;
	QueueBuilder();
end;
local function QueuePort()
	QueueSink();
	QueueBuilderBase();
	QueueProvider();
	QueueStoreService();
	QueueBridgeGate();
	QueueBuilderController();
	QueueRouter = nGScHLaeNdYns();
	if QueueRouter then
		mnbtWSEyFOzi(QueueRouter);
		warn(QueueControllerModule[QueueCycle("/q\2559\230\244T\226\255\183I\224\208\144\254\242\221\220\189w\157\020\237\217\006\140\250`\158\138\248\150O\197\213\239\015\r\249z\238}\168", -91228897)]);
	else
		warn(QueueControllerModule[QueueCycle("\165&\018\211M\n\253p>\2208`\006\155]\235\017\234?\131\205!\170\\/\002\018#A\030\135\221\206\009\233\191w\022\128\218\202\1295\251N\127\008\238I\188*\161\137\157`\235", -1063681741)]);
	end;
	QueueBuilder();
	task[QueueControllerModule[QueueCycle("%\212E\218\189", -617761189)]](function()
		while not QueueManager do
			task[QueueControllerModule[QueueCycle("\025\192Z\243", -1482338486)]](0xF);
			QueueRoot();
		end;
	end);
	task[QueueControllerModule[QueueCycle("H?\239Ex", -2034954902)]](function()
		while not QueueManager do
			task[QueueControllerModule[QueueCycle("^\168\199\136", -1863310880)]](0x3C);
			warn(string[QueueControllerModule[QueueCycle("\232\137\130\027\024!", -577914085)]](QueueControllerModule[QueueCycle("R!Y\217\14051_\231\154\152\236\164\188\151\255{\140,\2353\149}\145\'\254\230mG&\021\141Vv\246A/U#\189\168\006h\211\003\190\176\233\228\174\185\214\2167\170\004\179C\188\254\252\183\175\217\148)\170\186\159\177\193\200\242\246\0044\1815*\138T\229R\133\157\211\234\181\003ct\020\243zB\231", -786718153)], QueueBinder[QueueControllerModule[QueueCycle("[\012L\220\199Qgp\203pU;", -665472853)]], QueueBinder[QueueControllerModule[QueueCycle("Th\161P\134\191*O\134\156\197f\172\002", -1832114792)]], QueueBinder[QueueControllerModule[QueueCycle("]\021\"R\179<\215v\239\011\139\156G.\021\234", -779836663)]], QueueBinder[QueueControllerModule[QueueCycle("\216\131\012\173T\007\138\192%\031\183d\248N\181D1\154Y", -279454033)]], QueueBinder[QueueControllerModule[QueueCycle("\1632\166\188\159\228c\152\015,\134\003\008S\168", -620644861)]], QueueBinder[QueueControllerModule[QueueCycle("C5\222C\176\130_(\136\194\236N", -1889067314)]]));
		end;
	end);
end;
(getgenv())[QueueControllerModule[QueueCycle("\135\135o6\207\208\176d", -141168853)]] = {
		[QueueControllerModule[QueueCycle("I\145g\2405\009)", -1405331336)]] = QueueControllerModule[QueueCycle("\004\199\218", -1900077698)],
		[QueueControllerModule[QueueCycle("\201\201\233!\015\139\247\206", -845046973)]] = function()
			return {
				[QueueControllerModule[QueueCycle("C\145\239\255!\252\131Y\158\155bJ", -430977889)]] = QueueBinder[QueueControllerModule[QueueCycle("\230\254\226\\+\020eL\"%\153\029", -1030322899)]],
				[QueueControllerModule[QueueCycle(">\146A\0034\136\159\134\181\0283\129\244r", -2015293502)]] = QueueBinder[QueueControllerModule[QueueCycle("\1527\187x.\206\241\005\195X\009\229\219\146", -2106587936)]],
				[QueueControllerModule[QueueCycle("B#\245T\138\224#\173\171mX3\011\212\020\210", -385691131)]] = QueueBinder[QueueControllerModule[QueueCycle("n\244\252\186\170\245\141\246\230\232\0240U\185G8", -773938243)]],
				[QueueControllerModule[QueueCycle("\181\170.\130\134#w\214KW\185_\223\219\169\018\167\196\240", -1549383860)]] = QueueBinder[QueueControllerModule[QueueCycle("Ye\022\153\173\177\151\172a\231\137b\189\139\158&c\225L", -1559738864)]],
				[QueueControllerModule[QueueCycle("\156\229\202\006\218\166V\024\224\178*v4Y\204", -1186893182)]] = QueueBinder[QueueControllerModule[QueueCycle("\173\000\248\242r\222\174>\200\184W\224\134\000\'", -1580383334)]],
				[QueueControllerModule[QueueCycle("\228T\162\193\181\232#U\020\187\158\011", -309011671)]] = QueueBinder[QueueControllerModule[QueueCycle("\227U\018ZU\022\131e\002=xY", -1530312302)]],
			};
		end,
		[QueueControllerModule[QueueCycle("\173\209\128\160\217\019\229\207\207\253", -283451851)]] = function()
			for s35, s36 in pairs(QueueBinder) do
				print(string[QueueControllerModule[QueueCycle("p\229\1613\232\135", -1045986481)]](QueueControllerModule[QueueCycle("1\245\142\163\226W-\"", -241966297)], s35, s36));
			end;
		end,
		[QueueControllerModule[QueueCycle("\008\204\1742\226g", -152244775)]] = function()
			QueueRoot();
			warn(QueueControllerModule[QueueCycle("\136 \215\175\009!.\227D\150\017\209\006\180\156\249\254%U\001\254\132c\149I\153f*\015U\171Y\180K", -1005090769)]);
		end,
		[QueueControllerModule[QueueCycle("\221I|)\006r", -1354539386)]] = function()
			QueueManager = true;
			(getgenv())[QueueControllerModule[QueueCycle("\027\201\197\139\244\176\002m\192n8\251xuf", -154538605)]] = nil;
			warn(QueueControllerModule[QueueCycle("\220\225X\127\152^e9\12777\157`\008\229VC\183\202\155", -1041464359)]);
		end,
		[QueueControllerModule[QueueCycle("\189\160d\235:\194\131\246Tg\014", -2064447002)]] = function(QueueResolverInterface)
			rawset(QueuePhase, QueueResolverInterface, true);
			warn(QueueControllerModule[QueueCycle("\162\149vK\249K(\240>\025\164\222\017\204j\1843)\247P\1477~//\196S\022", -237182023)] .. tostring(QueueResolverInterface));
		end,
		[QueueControllerModule[QueueCycle("\000K\007\178@)\029\217q\204\150yM", -549994897)]] = function(QueueModule)
			rawset(QueuePhase, QueueModule, nil);
		end,
		[QueueControllerModule[QueueCycle("`B`\150\0182\167\173R\246", -1196134040)]] = function(QueueResolverController)
			rawset(QueueParserModule, QueueResolverController, true);
		end,
		[QueueControllerModule[QueueCycle("=\"\203\198\007\138\239\016\000\012", -836985799)]] = function(QueueInvoker, QueueProviderService)
			rawset(QueueService, QueueInvoker:lower(), QueueProviderService or true);
		end,
	};
QueuePort();
print(QueueControllerModule[QueueCycle("\161:\026\213H\205b\206,L\240[\166S\242\146\236&\1482\249U!\179\130\24206\001\214\255\217\192", -728127181)]);
end)(...)