@echo off
title Zuraph CLI Runner
set /p target=Drag script here: 

echo.
set /p luau_choice=Enable LuaU mode? (y/n, default=n): 

set opt=
if /i "%luau_choice%"=="y" (
    set opt=--LuaU
)

echo.
echo Executing: .\lua.exe cli.lua --preset ZuraphMax %opt% %target%
echo ---------------------------------------------------------
.\lua.exe cli.lua --preset ZuraphMax %opt% %target%
echo ---------------------------------------------------------
echo.
echo Done.
pause