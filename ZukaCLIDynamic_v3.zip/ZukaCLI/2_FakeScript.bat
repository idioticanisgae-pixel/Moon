@echo off
title CLI
set /p target=name of script: 

echo.
set /p luau_choice=Enable LuaU mode? (y/n, default=n): 

set opt=
if /i "%luau_choice%"=="y" (
    set opt=--LuaU
)

echo.
echo Executing: .\lua.exe cli.lua --preset 1 %opt% %target%
echo ---------------------------------------------------------
.\lua.exe cli.lua --preset 1 %opt% %target%
echo ---------------------------------------------------------
echo.
echo Done.
pause