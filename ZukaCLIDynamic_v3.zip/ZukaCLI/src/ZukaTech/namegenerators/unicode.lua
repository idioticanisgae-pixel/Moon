-- namegenerators/unicode.lua
-- Generates names using unicode lookalike characters
-- Visually identical to ASCII but completely different strings
-- Makes manual analysis and ctrl+F useless

local util = require("ZukaTech.util")

-- Full lookalike map: latin -> cyrillic/greek/other unicode equivalent
local lookalikes = {
    ["a"] = "\xD0\xB0",  -- Cyrillic а
    ["b"] = "\xD0\xB2",  -- Cyrillic в (close enough)
    ["c"] = "\xD1\x81",  -- Cyrillic с
    ["d"] = "\xD0\xB4",  -- Cyrillic д (close)
    ["e"] = "\xD0\xB5",  -- Cyrillic е
    ["h"] = "\xD0\xBD",  -- Cyrillic н (looks like h)
    ["i"] = "\xD1\x96",  -- Ukrainian і
    ["j"] = "\xD0\xB9",  -- Cyrillic й (close)
    ["k"] = "\xD0\xBA",  -- Cyrillic к
    ["m"] = "\xD0\xBC",  -- Cyrillic м
    ["n"] = "\xD0\xBD",  -- Cyrillic н
    ["o"] = "\xD0\xBE",  -- Cyrillic о
    ["p"] = "\xD1\x80",  -- Cyrillic р
    ["r"] = "\xD1\x8B",  -- Cyrillic ы (close)
    ["s"] = "\xD1\x95",  -- Cyrillic ѕ
    ["t"] = "\xD1\x82",  -- Cyrillic т
    ["u"] = "\xD1\x83",  -- Cyrillic у
    ["v"] = "\xD0\xBD",  -- Cyrillic н (v substitute)
    ["x"] = "\xD1\x85",  -- Cyrillic х
    ["y"] = "\xD1\x83",  -- Cyrillic у (y substitute)
}

-- Base charset for structure
local VarStartDigits = {}
local VarDigits      = {}

for c in ("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"):gmatch(".") do
    table.insert(VarStartDigits, c)
end
for c in ("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_"):gmatch(".") do
    table.insert(VarDigits, c)
end

-- Chance a character gets substituted with its lookalike (0.0 - 1.0)
local SUBSTITUTE_CHANCE = 0.7

local function substitute(ch)
    local lower = ch:lower()
    if lookalikes[lower] and math.random() < SUBSTITUTE_CHANCE then
        return lookalikes[lower]
    end
    return ch
end

local function generateName(id, scope)
    local name = ""
    local d = id % #VarStartDigits
    id = (id - d) / #VarStartDigits
    name = name .. substitute(VarStartDigits[d + 1])
    while id > 0 do
        local dd = id % #VarDigits
        id = (id - dd) / #VarDigits
        name = name .. substitute(VarDigits[dd + 1])
    end
    return name
end

local function prepare(ast)
    util.shuffle(VarDigits)
    util.shuffle(VarStartDigits)
end

return {
    generateName = generateName,
    prepare      = prepare,
}
