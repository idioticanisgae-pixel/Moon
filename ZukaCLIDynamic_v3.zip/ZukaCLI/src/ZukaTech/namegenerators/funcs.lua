-- ZukaTech Obfuscator — namegenerators/Rblx.lua
-- Generates plausible Roblox-internal-looking identifiers
-- so obfuscated code reads like legitimate engine/framework code.

local util = require("ZukaTech.util")

-- ────────────────────────────────────────────────
-- Word banks
-- ────────────────────────────────────────────────

local prefixes = {
	"Instance", "Remote", "Script", "Player", "Character",
	"Network", "Render", "Physics", "Replication", "Signal",
	"Module", "Object", "Service", "Core", "Internal",
	"Local", "Server", "Client", "Shared", "Utility",
	"Data", "Cache", "Event", "Task", "Thread",
	"Stream", "Buffer", "Queue", "Stack", "Registry",
         "getraw", "_namecal",
}

local middles = {
	"Handler", "Manager", "Controller", "Dispatcher", "Resolver",
	"Loader", "Builder", "Studio", "Provider", "Listener",
	"Tracker", "Monitor", "Scheduler", "Processor", "Executor",
	"Wrapper", "Adapter", "Bridge", "Router", "Validator",
	"Encoder", "Decoder", "Parser", "Formatter", "Serializer",
	"Context", "Config", "State", "Store", "Registry", "_Vector3",
}

local suffixes = {
	"Impl", "Base", "Core", "Util", "Helper",
	"Node", "Leaf", "Root", "Sink", "Source",
	"Hook", "Slot", "Port", "Gate", "Frame",
	"Step", "Pass", "Stage", "Phase", "Cycle",
	"Map", "Set", "List", "Pool", "Heap",
}

local snake_parts = {
	"instance", "remote", "script", "player", "character",
	"network", "render", "physics", "signal", "module",
	"object", "service", "core", "server", "client",
	"data", "cache", "event", "task", "thread",
	"handler", "manager", "loader", "factory", "listener",
	"tracker", "scheduler", "processor", "wrapper", "router",
	"impl", "base", "util", "node", "sink",
	"hook", "slot", "port", "gate", "step",
	"map", "pool", "state", "store", "context",
}

local short_bases = { "n", "v", "k", "t", "s", "p", "r", "c", "i", "j" }

-- ────────────────────────────────────────────────
-- Per-run state
-- ────────────────────────────────────────────────

local _used    = {}
local _counter = 0

local function resetState()
	_used    = {}
	_counter = 0
end

-- ────────────────────────────────────────────────
-- Helpers
-- ────────────────────────────────────────────────

local function pick(t, seed)
	-- deterministic pick when seed provided, random otherwise
	if seed then
		return t[(seed % #t) + 1]
	end
	return t[math.random(1, #t)]
end

local function scopeLevel(scope)
	if type(scope) == "table" then
		return tonumber(scope.level or scope.depth or 0) or 0
	elseif type(scope) == "number" then
		return scope
	end
	return 0
end

-- ────────────────────────────────────────────────
-- Name builders
-- ────────────────────────────────────────────────

local function camelName(seed)
	local style = (seed % 3)
	if style == 0 then
		return pick(prefixes, seed) .. pick(middles, seed + 7)
	elseif style == 1 then
		return pick(prefixes, seed + 3) .. pick(suffixes, seed + 11)
	else
		return pick(prefixes, seed + 1) .. pick(middles, seed + 5) .. pick(suffixes, seed + 13)
	end
end

local function snakeName(seed)
	local parts = (seed % 2) + 2  -- 2 or 3 parts
	local t = {}
	for i = 1, parts do
		t[i] = pick(snake_parts, seed + i * 17)
	end
	return table.concat(t, "_")
end

local function shortName(id)
	_counter = _counter + 1
	return pick(short_bases, id) .. tostring(_counter)
end

-- ────────────────────────────────────────────────
-- Public: generateName(id, scope, originalName)
-- ────────────────────────────────────────────────

local function generateName(id, scope, originalName)
	local level = scopeLevel(scope)

	-- depth 0/1 → camelCase  (top-level, module scope)
	-- depth 2/3 → snake_case (function scope)
	-- depth 4+  → short var  (inner loops/blocks)
	local style
	if level <= 1 then
		style = "camel"
	elseif level <= 3 then
		style = "snake"
	else
		style = "short"
	end

	local name
	local attempts = 0
	local seed = id

	repeat
		if style == "camel" then
			name = camelName(seed)
		elseif style == "snake" then
			name = snakeName(seed)
		else
			name = shortName(seed)
		end

		-- bump seed on collision
		if _used[name] then
			seed = (seed * 1664525 + 1013904223) % 0x7FFFFFFF
			name = nil
		end

		attempts = attempts + 1
	until name ~= nil or attempts > 128

	-- absolute fallback: originalName with numeric suffix
	if name == nil then
		name = (originalName or "v") .. tostring(id)
	end

	_used[name] = true
	return name
end

-- ────────────────────────────────────────────────
-- Public: prepare(ast)  — called once before renaming
-- ────────────────────────────────────────────────

local function prepare(ast)
	resetState()
	-- shuffle word banks so each run produces different names
	util.shuffle(prefixes)
	util.shuffle(middles)
	util.shuffle(suffixes)
	util.shuffle(snake_parts)
	util.shuffle(short_bases)
end

-- ────────────────────────────────────────────────

return {
	generateName = generateName,
	prepare      = prepare,
}