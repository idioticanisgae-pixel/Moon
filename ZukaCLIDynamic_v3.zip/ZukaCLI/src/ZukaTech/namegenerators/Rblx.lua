-- ZukaTech Obfuscator — namegenerators/Rblx.lua
-- All-in-one: Rblx + Rblxcryptic merged.

local util = require("ZukaTech.util")

-- ════════════════════════════════════════════════
-- § LCG CORE  (shared by both halves)
-- ════════════════════════════════════════════════

-- Per-run entropy salt injected by prepare() via os.time() + os.clock()
-- This ensures identical ids produce different names across obfuscation runs.
local _runSalt = 0

local function _bumpSeed(seed)
	return (seed * 1664525 + 1013904223) % 0x7FFFFFFF
end

-- Mix salt + id together through several LCG rounds before use
local function _saltedSeed(id)
	local s = (id + _runSalt) % 0x7FFFFFFF
	s = _bumpSeed(s)
	s = _bumpSeed(s)
	s = _bumpSeed(s)
	return s
end

-- Returns value in [0, range), plus the advanced seed
local function _randInt(seed, range)
	seed = _bumpSeed(seed)
	-- Extra mix to reduce low-value clustering on small ranges (fix [8])
	seed = _bumpSeed(seed)
	return seed % range, seed
end

-- ════════════════════════════════════════════════
-- § CRYPTIC  (was Rblxcryptic.lua)
-- ════════════════════════════════════════════════

local CRYPTIC_CFG = {
	hex = {
		minSegments   = 2,
		maxSegments   = 4,
		-- "word" = 0x0000-0xFFFF (4 hex digits)
		-- "byte" = 0x00-0xFF     (2 hex digits)
		segmentSize   = "word",
		separator     = "_",
		segmentPrefix = "0x",
		uppercase     = true,
	},
	letter = {
		minLen = 8,
		maxLen = 14,
		-- { char, weight } - higher weight = appears more often
		pool = {
			{ "a", 3 }, { "e", 3 }, { "i", 3 }, { "n", 3 },
			{ "o", 3 }, { "r", 3 }, { "s", 3 }, { "t", 3 },
			{ "b", 1 }, { "c", 1 }, { "d", 1 }, { "f", 1 },
			{ "g", 1 }, { "h", 1 }, { "k", 1 }, { "l", 1 },
			{ "m", 1 }, { "p", 1 }, { "q", 1 }, { "u", 1 },
			{ "v", 1 }, { "w", 1 }, { "x", 1 }, { "y", 1 },
			{ "z", 1 },
			{ "A", 1 }, { "B", 1 }, { "C", 1 }, { "D", 1 },
			{ "E", 1 }, { "F", 1 }, { "G", 1 }, { "H", 1 },
			{ "I", 1 }, { "J", 1 }, { "K", 1 }, { "L", 1 },
			{ "M", 1 }, { "N", 1 }, { "O", 1 }, { "P", 1 },
			{ "Q", 1 }, { "R", 1 }, { "S", 1 }, { "T", 1 },
			{ "U", 1 }, { "V", 1 }, { "W", 1 }, { "X", 1 },
			{ "Y", 1 }, { "Z", 1 },
		},
		-- Lowercase-only pool used for the forced first character (fix [7])
		firstCharPool = {
			"a","b","c","d","e","f","g","h","i","j","k","l","m",
			"n","o","p","q","r","s","t","u","v","w","x","y","z",
		},
	},
}

local _flatPool      = {}
local _flatPoolSize  = 0
local _firstCharPool = {}
local _firstCharSize = 0

local function _rebuildPool()
	_flatPool = {}
	for _, entry in ipairs(CRYPTIC_CFG.letter.pool) do
		local char, weight = entry[1], entry[2]
		for _ = 1, weight do
			_flatPool[#_flatPool + 1] = char
		end
	end
	_flatPoolSize = #_flatPool

	_firstCharPool = CRYPTIC_CFG.letter.firstCharPool or {}
	_firstCharSize = #_firstCharPool
end
_rebuildPool()

local function crypticConfigure(overrides)
	if not overrides then return end
	for section, vals in pairs(overrides) do
		if CRYPTIC_CFG[section] and type(vals) == "table" then
			for k, v in pairs(vals) do
				CRYPTIC_CFG[section][k] = v
			end
		end
	end
	if overrides.letter then _rebuildPool() end
end

local function crypticSnapshot()
	local snap = {}
	for k, v in pairs(CRYPTIC_CFG) do
		snap[k] = {}
		for sk, sv in pairs(v) do snap[k][sk] = sv end
	end
	return snap
end

local function crypticRestore(snap)
	for k, v in pairs(snap) do
		CRYPTIC_CFG[k] = {}
		for sk, sv in pairs(v) do CRYPTIC_CFG[k][sk] = sv end
	end
	_rebuildPool()
end

local SEGMENT_WIDTHS = { byte = 2, word = 4 }

local function buildHex(seed, _scopeKey)
	local hcfg   = CRYPTIC_CFG.hex
	local width  = SEGMENT_WIDTHS[hcfg.segmentSize] or 4
	local maxVal = 1
	for _ = 1, width do maxVal = maxVal * 16 end

	local segRange    = hcfg.maxSegments - hcfg.minSegments + 1
	local segCount, s = _randInt(seed, segRange)
	segCount = segCount + hcfg.minSegments

	local fmtChar = hcfg.uppercase and "X" or "x"
	local fmt     = hcfg.segmentPrefix .. "%0" .. width .. fmtChar

	local parts = {}
	for i = 1, segCount do
		local val
		-- Prime multiplier per segment so adjacent segments diverge (fix [8])
		val, s   = _randInt(s + i * 7919, maxVal)
		parts[i] = string.format(fmt, val)
	end

	return "_" .. table.concat(parts, hcfg.separator)
end

local function buildLetter(seed, _scopeKey)
	local lcfg     = CRYPTIC_CFG.letter
	local lenRange = lcfg.maxLen - lcfg.minLen + 1
	local len, s   = _randInt(seed, lenRange)
	len = len + lcfg.minLen

	local chars = {}

	-- Fix [7]: force lowercase first char — valid Lua identifier guaranteed
	if _firstCharSize > 0 then
		local idx
		idx, s   = _randInt(s, _firstCharSize)
		chars[1] = _firstCharPool[idx + 1]
	else
		chars[1] = "v"
	end

	for i = 2, len do
		local idx
		idx, s   = _randInt(s + i * 13, _flatPoolSize)
		chars[i] = _flatPool[idx + 1]
	end

	return table.concat(chars)
end

local function buildCryptic(style, seed, scopeKey)
	if style == "hex" then
		return buildHex(seed, scopeKey)
	else
		return buildLetter(seed, scopeKey)
	end
end

-- ════════════════════════════════════════════════
-- § RBLX
-- ════════════════════════════════════════════════

local CFG = {
	SHORT_DEPTH          = 3,
	SNAKE_DEPTH          = 6,
	MIXED_DEPTH_CHANCE   = 0.45,
	SERVICE_STYLE_CHANCE = 0.25,
	FAMILY_CHANCE        = 0.35,
	-- 0.0-1.0: chance any name uses a cryptic style (hex or letter)
	CRYPTIC_CHANCE       = 0.15,
}

local prefixes = {
	"Instance", "Remote", "Script", "Player", "Character",
	"Network", "Render", "Physics", "Replication", "Signal",
	"Module", "Object", "Service", "Core", "Bindable",
	"Local", "Server", "Client", "Shared", "Utility",
	"Workspace", "Cache", "Event", "Task", "Thread",
	"Stream", "Roblox", "Queue", "Stack", "Registry",
}

local middles = {
	"Handler", "Manager", "Controller", "Dispatcher", "Collector",
	"Emitter", "Builder", "Resolver", "Provider", "Listener",
	"Tracker", "Invoker", "Scheduler", "Allocator", "Executor",
	"Wrapper", "Adapter", "Bridge", "Router", "Validator",
	"Encoder", "Binder", "Parser", "Connector", "Initializer",
	"Context", "Config", "State", "Store", "Registry",
}

local suffixes = {
	"Impl", "Base", "Core", "Util", "Helper",
	"Node", "Leaf", "Root", "Sink", "Source",
	"Hook", "Slot", "Port", "Gate", "Frame",
	"Step", "Pass", "Stage", "Phase", "Cycle",
	"Map", "Set", "List", "Pool", "Heap",
}

local service_suffixes = {
	"Service", "Controller", "Provider", "Manager",
	"Handler", "System", "Interface", "Module",
}

local snake_parts = {
	"instance", "remote", "script", "player", "character",
	"network", "render", "physics", "signal", "module",
	"object", "service", "core", "server", "client",
	"data", "cache", "event", "task", "thread",
	"handler", "manager", "loader", "factory", "listener",
	"tracker", "scheduler", "processor", "wrapper", "router",
	"impl", "base", "util", "node", "sink",
	"hook", "slot", "port", "gate", "step",
	"map", "pool", "state", "store", "context",
}

local short_bases = { "n", "v", "k", "t", "s", "p", "r", "c", "i", "j" }

local _globalUsed    = {}
local _scopeUsed     = {}
local _scopeFamily   = {}
local _scopeCounters = {}

local function resetState()
	_globalUsed    = {}
	_scopeUsed     = {}
	_scopeFamily   = {}
	_scopeCounters = {}
end

local function pick(t, seed)
	seed = _bumpSeed(seed)
	return t[(seed % #t) + 1]
end

local function scopeLevel(scope)
	if type(scope) == "table" then
		return tonumber(scope.level or scope.depth or 0) or 0
	elseif type(scope) == "number" then
		return scope
	end
	return 0
end

local function makeScopeKey(scope)
	if type(scope) == "table" then
		return tostring(scope)
	end
	return "scalar_" .. tostring(scope)
end

local function isUsed(name, scopeKey)
	if _globalUsed[name] then return true end
	if _scopeUsed[scopeKey] and _scopeUsed[scopeKey][name] then return true end
	return false
end

local function markUsed(name, scopeKey)
	_globalUsed[name] = true
	if not _scopeUsed[scopeKey] then _scopeUsed[scopeKey] = {} end
	_scopeUsed[scopeKey][name] = true
end

local function getFamilyPrefix(scopeKey, seed)
	if _scopeFamily[scopeKey] == nil then
		local roll = (_bumpSeed(seed) % 100) / 100.0
		if roll < CFG.FAMILY_CHANCE then
			_scopeFamily[scopeKey] = pick(prefixes, seed)
		else
			_scopeFamily[scopeKey] = false
		end
	end
	return _scopeFamily[scopeKey]
end

local function buildCamel(seed, scopeKey)
	local family = getFamilyPrefix(scopeKey, seed)
	local root   = family or pick(prefixes, seed)

	local serviceRoll = (_bumpSeed(seed) % 100) / 100.0
	if serviceRoll < CFG.SERVICE_STYLE_CHANCE then
		local svcSfx = pick(service_suffixes, _bumpSeed(_bumpSeed(seed)))
		if seed % 2 == 0 then
			return root .. svcSfx
		else
			return root .. pick(middles, _bumpSeed(seed)) .. svcSfx
		end
	end

	local style = seed % 3
	if style == 0 then
		return root .. pick(middles, seed + 7)
	elseif style == 1 then
		return root .. pick(suffixes, seed + 11)
	else
		return root .. pick(middles, seed + 5) .. pick(suffixes, seed + 13)
	end
end

local function buildSnake(seed, scopeKey)
	local family = getFamilyPrefix(scopeKey, seed)
	local parts  = (seed % 2) + 2
	local t      = {}

	if family then
		t[1] = string.lower(family)
		for i = 2, parts do
			t[i] = pick(snake_parts, seed + i * 17)
		end
	else
		for i = 1, parts do
			t[i] = pick(snake_parts, seed + i * 17)
		end
	end
	return table.concat(t, "_")
end

local function buildShort(seed, scopeKey)
	_scopeCounters[scopeKey] = (_scopeCounters[scopeKey] or 0) + 1
	return pick(short_bases, seed) .. tostring(_scopeCounters[scopeKey])
end

local function chooseStyle(level, seed)
	-- Depth-based primary style
	local primary
	if level >= CFG.SNAKE_DEPTH then
		local roll = (_bumpSeed(seed) % 100) / 100.0
		primary = (roll < CFG.MIXED_DEPTH_CHANCE) and "camel" or "snake"
	elseif level >= CFG.SHORT_DEPTH then
		primary = "short"
	else
		primary = "camel"
	end

	-- Cryptic roll runs in a separate LCG lane — uncorrelated with depth roll
	local crypticSeed = _bumpSeed(seed * 31337 % 0x7FFFFFFF)
	local crypticRoll = (crypticSeed % 100) / 100.0
	if crypticRoll < CFG.CRYPTIC_CHANCE then
		local subSeed = _bumpSeed(crypticSeed)
		return (subSeed % 2 == 0) and "hex" or "letter"
	end

	return primary
end

local function generateName(id, scope, originalName)
	local level    = scopeLevel(scope)
	local scopeKey = makeScopeKey(scope)
	local style    = chooseStyle(level, id)

	local name
	-- Fix [6]: salted seed ensures different output every run
	local seed     = _saltedSeed(id)
	local attempts = 0

	repeat
		if style == "camel" then
			name = buildCamel(seed, scopeKey)
		elseif style == "snake" then
			name = buildSnake(seed, scopeKey)
		elseif style == "short" then
			name = buildShort(seed, scopeKey)
		elseif style == "hex" then
			name = buildHex(seed, scopeKey)
		elseif style == "letter" then
			name = buildLetter(seed, scopeKey)
		end

		if isUsed(name, scopeKey) then
			seed = _bumpSeed(seed)
			name = nil
		end

		attempts = attempts + 1
	until name ~= nil or attempts > 128

	if name == nil then
		name = (originalName or "v") .. tostring(id)
	end

	markUsed(name, scopeKey)
	return name
end

local function prepare(ast)
	resetState()

	-- Fix [6]: combine os.time() + os.clock() for sub-second uniqueness.
	-- Two runs in the same wall-clock second will still diverge via clock().
	local timePart  = (os.time() or 0) % 0x7FFFFFFF
	local clockPart = math.floor((os.clock() * 1e6)) % 0x7FFFFFFF
	_runSalt = _bumpSeed((timePart + clockPart * 6364136 % 0x7FFFFFFF) % 0x7FFFFFFF)

	util.shuffle(prefixes)
	util.shuffle(middles)
	util.shuffle(suffixes)
	util.shuffle(service_suffixes)
	util.shuffle(snake_parts)
	util.shuffle(short_bases)
end

return {
	generateName     = generateName,
	prepare          = prepare,
	buildHex         = buildHex,
	buildLetter      = buildLetter,
	buildCryptic     = buildCryptic,
	crypticConfigure = crypticConfigure,
	crypticSnapshot  = crypticSnapshot,
	crypticRestore   = crypticRestore,
}