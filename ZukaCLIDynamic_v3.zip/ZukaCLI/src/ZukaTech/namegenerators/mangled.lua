-- ZukaTech Obfuscator — namegenerators/mangled.lua
-- Fixed: collision registry now auto-resolves instead of erroring.
-- Upgraded: wider encoding, scope-safe, pure Lua 5.1.

local util      = require("ZukaTech.util")
local chararray = util.chararray

-- ────────────────────────────────────────────────
-- Charsets
-- ────────────────────────────────────────────────

local VarDigits      = chararray("aAbBcCdDeEfFgGhHiIjJkKlLmMnNoOpPqQrRsStTuUvVwWxXyYzZ0123456789_")
local VarStartDigits = chararray("aAbBcCdDeEfFgGhHiIjJkKlLmMnNoOpPqQrRsStTuUvVwWxXyYzZ")

-- ────────────────────────────────────────────────
-- Config
-- ────────────────────────────────────────────────

-- Raised to 4 — reduces collision probability significantly.
-- At MIN_LENGTH=3 with 63-char tail, space = 52 * 63^2 = 206,388 names.
-- At MIN_LENGTH=4: 52 * 63^3 = 13,002,444 names. Collisions become negligible.
local MIN_LENGTH = 4

-- Hard cap on resolution attempts before giving up.
local MAX_RESOLVE_ATTEMPTS = 64

local RESERVED = {
    ["and"]=true,["break"]=true,["do"]=true,["else"]=true,["elseif"]=true,
    ["end"]=true,["false"]=true,["for"]=true,["function"]=true,["if"]=true,
    ["in"]=true,["local"]=true,["nil"]=true,["not"]=true,["or"]=true,
    ["repeat"]=true,["return"]=true,["then"]=true,["true"]=true,
    ["until"]=true,["while"]=true,
}

-- ────────────────────────────────────────────────
-- Per-run State
-- ────────────────────────────────────────────────

-- Registry maps name → assigned id. Used to detect and resolve collisions.
local _registry = {}

local function resetRegistry()
    _registry = {}
end

-- ────────────────────────────────────────────────
-- Core Encoder
-- ────────────────────────────────────────────────

---@param id number
---@return string
local function encodeId(id)
    assert(id >= 0, "[mangled] id must be non-negative")

    local name = ""

    local d = id % #VarStartDigits
    id      = math.floor((id - d) / #VarStartDigits)
    name    = VarStartDigits[d + 1]

    while id > 0 do
        d    = id % #VarDigits
        id   = math.floor((id - d) / #VarDigits)
        name = name .. VarDigits[d + 1]
    end

    -- Pad to MIN_LENGTH with deterministic chars.
    local v = id
    local padPos = #name
    while #name < MIN_LENGTH do
        v      = (v * 1664525 + 1013904223) % 0xFFFFFFFF
        padPos = padPos + 1
        name   = name .. VarDigits[(v % #VarDigits) + 1]
    end

    return name
end

-- ────────────────────────────────────────────────
-- Scope Safety
-- ────────────────────────────────────────────────

local function scopeDepth(scope)
    if type(scope) == "number" then
        return scope
    elseif type(scope) == "table" then
        return tonumber(scope.depth or scope.level or scope.id or 0) or 0
    end
    return 0
end

-- ────────────────────────────────────────────────
-- Public: generateName
-- ────────────────────────────────────────────────

---@param id    number
---@param scope any
---@return string
local function generateName(id, scope)
    local depth = scopeDepth(scope)
    if depth > 0 then
        id = (id * 2654435761 + depth * 2246822519) % 0xFFFFFFFF
    end

    local attempt = 0
    local name

    repeat
        name = encodeId(id)

        -- Reserved word guard.
        if RESERVED[name] then
            id   = (id + 0xFFFF) % 0xFFFFFFFF
            name = nil
        -- Collision resolution: if this name is already taken by a DIFFERENT id,
        -- bump the id forward and re-encode. No error — silent auto-resolve.
        elseif _registry[name] ~= nil and _registry[name] ~= id then
            id      = (id + 1) % 0xFFFFFFFF
            name    = nil
            attempt = attempt + 1
        end

    until name ~= nil or attempt >= MAX_RESOLVE_ATTEMPTS

    -- Absolute fallback: if we exhausted resolution attempts (extremely rare),
    -- append attempt count as a suffix to guarantee uniqueness.
    if name == nil then
        name = encodeId(id) .. VarDigits[(attempt % #VarDigits) + 1]
    end

    _registry[name] = id
    return name
end

-- ────────────────────────────────────────────────
-- Public: prepare
-- ────────────────────────────────────────────────

local function prepare(ast)
    util.shuffle(VarDigits)
    util.shuffle(VarStartDigits)
    resetRegistry()
end

-- ────────────────────────────────────────────────

return {
    generateName = generateName,
    prepare      = prepare,
}