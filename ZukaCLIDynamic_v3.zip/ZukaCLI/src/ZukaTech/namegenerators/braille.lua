-- namegenerators/braille.lua
-- Braille — by Zuka
--
-- Variable names built entirely from Unicode Braille Pattern characters
-- (U+2800–U+28FF). Every name looks like a wall of dots.
--
-- Visually: ⠗⠑⠎⠥⠇⠞  ⠏⠗⠕⠉⠑⠎⠎  ⠎⠞⠁⠉⠅
--
-- Why it's brutal:
--   - All 256 braille glyphs look nearly identical at normal font sizes
--   - Ctrl+F, grep, and most tooling render them as boxes or garbage
--   - The names are valid Lua 5.1 identifiers (bytes >= 0x80)
--   - Decompilers and syntax highlighters have no idea what to do with them
--   - Two names that LOOK identical to the human eye are actually different

local util = require("ZukaTech.util")

-- 64 braille characters sampled from the block for variety
-- Chosen to maximize visual similarity to each other
local BRAILLE = {
    "\xE2\xA0\x80", -- ⠀ U+2800 BRAILLE PATTERN BLANK
    "\xE2\xA0\x81", -- ⠁ U+2801
    "\xE2\xA0\x82", -- ⠂ U+2802
    "\xE2\xA0\x83", -- ⠃ U+2803
    "\xE2\xA0\x84", -- ⠄ U+2804
    "\xE2\xA0\x85", -- ⠅ U+2805
    "\xE2\xA0\x86", -- ⠆ U+2806
    "\xE2\xA0\x87", -- ⠇ U+2807
    "\xE2\xA0\x88", -- ⠈ U+2808
    "\xE2\xA0\x89", -- ⠉ U+2809
    "\xE2\xA0\x8A", -- ⠊ U+280A
    "\xE2\xA0\x8B", -- ⠋ U+280B
    "\xE2\xA0\x8C", -- ⠌ U+280C
    "\xE2\xA0\x8D", -- ⠍ U+280D
    "\xE2\xA0\x8E", -- ⠎ U+280E
    "\xE2\xA0\x8F", -- ⠏ U+280F
    "\xE2\xA0\x90", -- ⠐ U+2810
    "\xE2\xA0\x91", -- ⠑ U+2811
    "\xE2\xA0\x92", -- ⠒ U+2812
    "\xE2\xA0\x93", -- ⠓ U+2813
    "\xE2\xA0\x94", -- ⠔ U+2814
    "\xE2\xA0\x95", -- ⠕ U+2815
    "\xE2\xA0\x96", -- ⠖ U+2816
    "\xE2\xA0\x97", -- ⠗ U+2817
    "\xE2\xA0\x98", -- ⠘ U+2818
    "\xE2\xA0\x99", -- ⠙ U+2819
    "\xE2\xA0\x9A", -- ⠚ U+281A
    "\xE2\xA0\x9B", -- ⠛ U+281B
    "\xE2\xA0\x9C", -- ⠜ U+281C
    "\xE2\xA0\x9D", -- ⠝ U+281D
    "\xE2\xA0\x9E", -- ⠞ U+281E
    "\xE2\xA0\x9F", -- ⠟ U+281F
    "\xE2\xA0\xA0", -- ⠠ U+2820
    "\xE2\xA0\xA1", -- ⠡ U+2821
    "\xE2\xA0\xA2", -- ⠢ U+2822
    "\xE2\xA0\xA3", -- ⠣ U+2823
    "\xE2\xA0\xA4", -- ⠤ U+2824
    "\xE2\xA0\xA5", -- ⠥ U+2825
    "\xE2\xA0\xA6", -- ⠦ U+2826
    "\xE2\xA0\xA7", -- ⠧ U+2827
    "\xE2\xA0\xA8", -- ⠨ U+2828
    "\xE2\xA0\xA9", -- ⠩ U+2829
    "\xE2\xA0\xAA", -- ⠪ U+282A
    "\xE2\xA0\xAB", -- ⠫ U+282B
    "\xE2\xA0\xAC", -- ⠬ U+282C
    "\xE2\xA0\xAD", -- ⠭ U+282D
    "\xE2\xA0\xAE", -- ⠮ U+282E
    "\xE2\xA0\xAF", -- ⠯ U+282F
    "\xE2\xA0\xB0", -- ⠰ U+2830
    "\xE2\xA0\xB1", -- ⠱ U+2831
    "\xE2\xA0\xB2", -- ⠲ U+2832
    "\xE2\xA0\xB3", -- ⠳ U+2833
    "\xE2\xA0\xB4", -- ⠴ U+2834
    "\xE2\xA0\xB5", -- ⠵ U+2835
    "\xE2\xA0\xB6", -- ⠶ U+2836
    "\xE2\xA0\xB7", -- ⠷ U+2837
    "\xE2\xA0\xB8", -- ⠸ U+2838
    "\xE2\xA0\xB9", -- ⠹ U+2839
    "\xE2\xA0\xBA", -- ⠺ U+283A
    "\xE2\xA0\xBB", -- ⠻ U+283B
    "\xE2\xA0\xBC", -- ⠼ U+283C
    "\xE2\xA0\xBD", -- ⠽ U+283D
    "\xE2\xA0\xBE", -- ⠾ U+283E
    "\xE2\xA0\xBF", -- ⠿ U+283F
}

local MIN_LEN = 3
local MAX_LEN = 7

local order  = {}
local seed   = 0

local function prng(n)
    n = (n * 2654435761 + seed) % 0x100000000
    -- manual xor with shr 16
    local a      = math.floor(n / 65536)
    local result = 0
    local bit    = 1
    local x, y   = n, a
    for _ = 1, 32 do
        if x % 2 ~= y % 2 then result = result + bit end
        x   = math.floor(x / 2)
        y   = math.floor(y / 2)
        bit = bit * 2
    end
    return result
end

local function generateName(id, scope)
    local len  = MIN_LEN + (prng(id) % (MAX_LEN - MIN_LEN + 1))
    local name = ""
    for i = 0, len - 1 do
        local idx = (prng(id * 7 + i * 31) % #order) + 1
        name = name .. BRAILLE[order[idx]]
    end
    return "_" .. name
end

local function prepare(ast)
    seed  = math.random(0, 0xFFFFFF)
    order = {}
    for i = 1, #BRAILLE do order[i] = i end
    util.shuffle(order)
end

return {
    generateName = generateName,
    prepare      = prepare,
}
