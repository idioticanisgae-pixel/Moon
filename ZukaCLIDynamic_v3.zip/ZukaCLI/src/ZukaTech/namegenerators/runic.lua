-- namegenerators/runic.lua
-- Runic — by Zuka
--
-- Variable names built from Elder Futhark + Runic Unicode block (U+16A0–U+16FF)
--
-- Visually: ᚱᚢᚾᛖ  ᚠᚢᚦᚨᚱᚲ  ᛊᛏᚨᚲ
--
-- Why it's brutal:
--   - Runes all look vaguely similar — tall vertical strokes with branches
--   - Valid Lua 5.1 identifiers (bytes >= 0x80)
--   - Zero tooling support — decompilers, linters, syntax highlighters all choke
--   - Visually striking — output looks like actual runic inscriptions
--   - Grep and ctrl+F require knowing the exact unicode codepoint

local util = require("ZukaTech.util")

local RUNES = {
    "\xE1\x9A\xA0", -- ᚠ U+16A0 RUNIC LETTER FEHU
    "\xE1\x9A\xA2", -- ᚢ U+16A2 RUNIC LETTER URUZ
    "\xE1\x9A\xA6", -- ᚦ U+16A6 RUNIC LETTER THURISAZ
    "\xE1\x9A\xA8", -- ᚨ U+16A8 RUNIC LETTER ANSUZ
    "\xE1\x9A\xB1", -- ᚱ U+16B1 RUNIC LETTER RAIDO
    "\xE1\x9A\xB2", -- ᚲ U+16B2 RUNIC LETTER KAUN
    "\xE1\x9A\xB7", -- ᚷ U+16B7 RUNIC LETTER GEBO
    "\xE1\x9A\xB9", -- ᚹ U+16B9 RUNIC LETTER WUNJO
    "\xE1\x9A\xBB", -- ᚻ U+16BB RUNIC LETTER HAEGL
    "\xE1\x9A\xBE", -- ᚾ U+16BE RUNIC LETTER NAUDIZ
    "\xE1\x9B\x96", -- ᛖ U+16D6 RUNIC LETTER EHWAZ
    "\xE1\x9B\x97", -- ᛗ U+16D7 RUNIC LETTER MANNAZ
    "\xE1\x9B\x9A", -- ᛚ U+16DA RUNIC LETTER LAUKAZ
    "\xE1\x9B\x9B", -- ᛛ U+16DB RUNIC LETTER DOTTED-L
    "\xE1\x9B\x9E", -- ᛞ U+16DE RUNIC LETTER DAGAZ
    "\xE1\x9B\x9F", -- ᛟ U+16DF RUNIC LETTER OTHALAN
    "\xE1\x9A\xA1", -- ᚡ U+16A1
    "\xE1\x9A\xA3", -- ᚣ U+16A3
    "\xE1\x9A\xA4", -- ᚤ U+16A4
    "\xE1\x9A\xA5", -- ᚥ U+16A5
    "\xE1\x9A\xA9", -- ᚩ U+16A9
    "\xE1\x9A\xAA", -- ᚪ U+16AA
    "\xE1\x9A\xAB", -- ᚫ U+16AB
    "\xE1\x9A\xAC", -- ᚬ U+16AC
    "\xE1\x9A\xAD", -- ᚭ U+16AD
    "\xE1\x9A\xAE", -- ᚮ U+16AE
    "\xE1\x9A\xAF", -- ᚯ U+16AF
    "\xE1\x9A\xB0", -- ᚰ U+16B0
    "\xE1\x9A\xB3", -- ᚳ U+16B3
    "\xE1\x9A\xB4", -- ᚴ U+16B4
    "\xE1\x9A\xB5", -- ᚵ U+16B5
    "\xE1\x9A\xB6", -- ᚶ U+16B6
    "\xE1\x9B\x80", -- ᛀ U+16C0
    "\xE1\x9B\x82", -- ᛂ U+16C2
    "\xE1\x9B\x83", -- ᛃ U+16C3
    "\xE1\x9B\x84", -- ᛄ U+16C4
    "\xE1\x9B\x85", -- ᛅ U+16C5
    "\xE1\x9B\x86", -- ᛆ U+16C6
    "\xE1\x9B\x87", -- ᛇ U+16C7
    "\xE1\x9B\x88", -- ᛈ U+16C8
    "\xE1\x9B\x89", -- ᛉ U+16C9
    "\xE1\x9B\x8A", -- ᛊ U+16CA
    "\xE1\x9B\x8B", -- ᛋ U+16CB
    "\xE1\x9B\x8C", -- ᛌ U+16CC
    "\xE1\x9B\x8D", -- ᛍ U+16CD
    "\xE1\x9B\x8E", -- ᛎ U+16CE
    "\xE1\x9B\x8F", -- ᛏ U+16CF RUNIC LETTER TIWAZ
    "\xE1\x9B\x90", -- ᛐ U+16D0
    "\xE1\x9B\x91", -- ᛑ U+16D1
    "\xE1\x9B\x92", -- ᛒ U+16D2 RUNIC LETTER BERKANAN
    "\xE1\x9B\x93", -- ᛓ U+16D3
    "\xE1\x9B\x94", -- ᛔ U+16D4
    "\xE1\x9B\x95", -- ᛕ U+16D5
    "\xE1\x9B\x98", -- ᛘ U+16D8
    "\xE1\x9B\x99", -- ᛙ U+16D9
    "\xE1\x9B\x9C", -- ᛜ U+16DC
    "\xE1\x9B\x9D", -- ᛝ U+16DD
    "\xE1\x9B\xA0", -- ᛠ U+16E0
    "\xE1\x9B\xA1", -- ᛡ U+16E1
    "\xE1\x9B\xA2", -- ᛢ U+16E2
    "\xE1\x9B\xA3", -- ᛣ U+16E3
    "\xE1\x9B\xA4", -- ᛤ U+16E4
    "\xE1\x9B\xA5", -- ᛥ U+16E5
    "\xE1\x9B\xA6", -- ᛦ U+16E6
}

local MIN_LEN = 3
local MAX_LEN = 8
local order   = {}
local seed    = 0

local function prng(n)
    n = (n * 2246822519 + seed * 2654435761) % 0x100000000
    local a, result, bit, x, y = math.floor(n / 65536), 0, 1, n, math.floor(n / 65536)
    for _ = 1, 32 do
        if x % 2 ~= y % 2 then result = result + bit end
        x = math.floor(x / 2); y = math.floor(y / 2); bit = bit * 2
    end
    return result
end

local function generateName(id, scope)
    local len  = MIN_LEN + (prng(id * 3) % (MAX_LEN - MIN_LEN + 1))
    local name = ""
    for i = 0, len - 1 do
        local idx = (prng(id * 13 + i * 7) % #order) + 1
        name = name .. RUNES[order[idx]]
    end
    return "_" .. name
end

local function prepare(ast)
    seed  = math.random(0, 0xFFFFFF)
    order = {}
    for i = 1, #RUNES do order[i] = i end
    util.shuffle(order)
end

return {
    generateName = generateName,
    prepare      = prepare,
}
