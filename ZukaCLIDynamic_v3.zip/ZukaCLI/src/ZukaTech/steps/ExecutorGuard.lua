-- This Script is Part of the ZukaTech Obfuscator by Levno_710
--
-- ExecutorGuard.lua
--
-- Pipeline step that prepends a hardened executor-environment guard at the
-- top of the AST (before Vmify runs, so it gets compiled into VM bytecode).
--
-- Checks performed at load-time and on a randomised recurring timer:
--   1. Studio block          — kills if RunService:IsStudio() is true.
--   2. Executor globals scan — verifies at least one known executor-only
--      global is present in getgenv() or _G.
--   3. load/loadstring check — ensures the function is an executor closure
--      or a native C closure, not a plain Lua hook.
--   4. checkcaller()         — wrapped in pcall (not all executors expose
--      it; a hard call would self-destruct on legitimate executors).
--   5. Persistent monitor    — re-runs the load/loadstring check every
--      [MinInterval, MaxInterval] seconds (randomised per compile) to
--      catch mid-session swaps.
--
-- Hardening over tamper.lua:
--   * Executor globals list is shuffled each compile — prevents static
--     fingerprinting of the scan order.
--   * Kill reason is a random alphanumeric string — no static error string.
--   * Poll interval is random in [MinInterval, MaxInterval].
--   * checkcaller() is pcall-wrapped — safe on executors that lack it.
--   * Silent-loop kill path used for the monitor instead of error() —
--     harder to catch with pcall wrappers.

local Step         = require("ZukaTech.step")
local Ast          = require("ZukaTech.ast")
local Parser       = require("ZukaTech.parser")
local Enums        = require("ZukaTech.enums")
local RandomStrings = require("ZukaTech.randomStrings")
local logger       = require("logger")

-- ---------------------------------------------------------------------------
-- Fisher-Yates shuffle (Lua 5.1 compatible, in-place)
-- ---------------------------------------------------------------------------
local function shuffleTable(t)
    for i = #t, 2, -1 do
        local j = math.random(1, i)
        t[i], t[j] = t[j], t[i]
    end
    return t
end

-- ---------------------------------------------------------------------------
-- Known executor-only globals — shuffled every compile.
-- ---------------------------------------------------------------------------
local EXECUTOR_GLOBALS = {
    "getgenv", "getrenv", "getrawmetatable", "setreadonly",
    "hookmetamethod", "hookfunction", "newcclosure",
    "getnamecallmethod", "checkcaller", "getconnections",
    "firesignal", "Drawing", "WebSocket", "request",
    "http_request", "readfile", "writefile", "isfile",
    "isfolder", "makefolder", "delfile", "isexecutorclosure",
    "clonefunction", "gethui", "setclipboard", "getclipboard",
    "rconsoleprint", "rconsoleclear", "queue_on_teleport",
}

-- ---------------------------------------------------------------------------
-- Step definition
-- ---------------------------------------------------------------------------
local ExecutorGuard       = Step:extend()
ExecutorGuard.Name        = "Executor Guard"
ExecutorGuard.Description =
    "Prepends a hardened executor-environment guard. " ..
    "Validates Studio block, executor globals, load/loadstring integrity, " ..
    "and checkcaller(). Includes a randomised persistent monitor thread. " ..
    "Best placed BEFORE Vmify so the guard is compiled into VM bytecode."

ExecutorGuard.SettingsDescriptor = {
    BlockStudio = {
        type        = "boolean",
        default     = true,
        description = "Kill execution when running inside Roblox Studio.",
    },
    CheckCallerGuard = {
        type        = "boolean",
        default     = true,
        description = "Include pcall-wrapped checkcaller() validation.",
    },
    PersistentMonitor = {
        type        = "boolean",
        default     = true,
        description = "Spawn a background thread that re-checks load/loadstring integrity on a random timer.",
    },
    MinInterval = {
        type        = "number",
        default     = 10,
        min         = 5,
        max         = 120,
        description = "Minimum seconds between persistent monitor polls.",
    },
    MaxInterval = {
        type        = "number",
        default     = 25,
        min         = 5,
        max         = 120,
        description = "Maximum seconds between persistent monitor polls.",
    },
    GlobalScanCount = {
        type        = "number",
        default     = 8,
        min         = 3,
        max         = 27,
        description = "How many executor globals to include in the scan (randomly sampled each compile).",
    },
}

function ExecutorGuard:init()
    -- Validate MinInterval <= MaxInterval at settings-load time so the
    -- user gets a clear error immediately rather than a silent swap later.
    if self.MinInterval and self.MaxInterval then
        if self.MinInterval > self.MaxInterval then
            logger:warn(string.format(
                "[ExecutorGuard] MinInterval (%d) > MaxInterval (%d) — values will be swapped at apply time.",
                self.MinInterval, self.MaxInterval
            ))
        end
    end
end

-- ---------------------------------------------------------------------------
-- Build the guard source, then parse + inject into the AST.
-- ---------------------------------------------------------------------------
function ExecutorGuard:apply(ast, pipeline)
    if pipeline.PrettyPrint then
        logger:warn(string.format(
            "[ExecutorGuard] cannot be used with PrettyPrint — skipping injection."
        ))
        return ast
    end

    logger:info(string.format(
        "[ExecutorGuard] injecting guard — Studio=%s  Caller=%s  Monitor=%s  Interval=[%d,%d]  GlobalScan=%d",
        tostring(self.BlockStudio),
        tostring(self.CheckCallerGuard),
        tostring(self.PersistentMonitor),
        self.MinInterval,
        self.MaxInterval,
        self.GlobalScanCount
    ))

    -- -----------------------------------------------------------------------
    -- Per-compile randomised values
    -- -----------------------------------------------------------------------
    local killStr    = RandomStrings.randomString(math.random(8, 20))
    local minT       = math.floor(self.MinInterval)
    local maxT       = math.floor(self.MaxInterval)
    if minT > maxT then minT, maxT = maxT, minT end

    -- Sample and shuffle the globals list
    local pool = {}
    for _, v in ipairs(EXECUTOR_GLOBALS) do pool[#pool + 1] = v end
    shuffleTable(pool)
    local scanCount = math.min(self.GlobalScanCount, #pool)
    local scanGlobals = {}
    for i = 1, scanCount do scanGlobals[i] = pool[i] end

    logger:info(string.format(
        "[ExecutorGuard] scanning globals (%d/%d sampled): %s",
        scanCount, #EXECUTOR_GLOBALS, table.concat(scanGlobals, ", ")
    ))

    -- Build the Lua string literal for the globals table
    -- e.g. {"getgenv","Drawing","request",...}
    local globalsLiteral = "{"
    for i, g in ipairs(scanGlobals) do
        globalsLiteral = globalsLiteral .. string.format('%q', g)
        if i < #scanGlobals then globalsLiteral = globalsLiteral .. "," end
    end
    globalsLiteral = globalsLiteral .. "}"

    -- Unique local names to reduce grep-ability
    local vKill     = "_eg" .. math.random(10000, 99999)
    local vGenv     = "_eg" .. math.random(10000, 99999)
    local vFound    = "_eg" .. math.random(10000, 99999)
    local vList     = "_eg" .. math.random(10000, 99999)
    local vG        = "_eg" .. math.random(10000, 99999)
    local vLoad     = "_eg" .. math.random(10000, 99999)
    local vFn       = "_eg" .. math.random(10000, 99999)
    local vIE       = "_eg" .. math.random(10000, 99999)
    local vIN       = "_eg" .. math.random(10000, 99999)

    -- -----------------------------------------------------------------------
    -- 1. Studio block
    -- -----------------------------------------------------------------------
    local studioBlock = ""
    if self.BlockStudio then
        studioBlock = string.format([[
    do
        local ok, isStudio = pcall(function()
            return game:GetService("RunService"):IsStudio()
        end)
        if ok and isStudio then
            local %s = %q
            while true do local _ = %s end
        end
    end
]], vKill, killStr, vKill)
    end

    -- -----------------------------------------------------------------------
    -- 2. Executor globals scan
    -- -----------------------------------------------------------------------
    local globalsBlock = string.format([[
    do
        local %s = %s
        local %s = (type(getgenv) == "function") and getgenv() or nil
        local %s = false
        for _, %s in ipairs(%s) do
            if %s and type(%s) == "table" and rawget(%s, %s) ~= nil then
                %s = true; break
            end
            if type(_G) == "table" and rawget(_G, %s) ~= nil then
                %s = true; break
            end
        end
        if not %s then
            local %s = %q
            while true do local _ = %s end
        end
    end
]],
        vList, globalsLiteral,             -- local list = {...}
        vGenv,                             -- local genv = ...
        vFound,                            -- local found = false
        vG, vList,                         -- for _, g in ipairs(list)
        vGenv, vGenv, vGenv, vG,           --   genv table check
        vFound,                            --   found = true
        vG, vFound,                        --   _G check / found = true
        vFound,                            -- if not found then
        vKill, killStr, vKill              --   kill loop
    )

    -- -----------------------------------------------------------------------
    -- 3. load/loadstring integrity check (initial)
    -- -----------------------------------------------------------------------
    local integrityCheck = string.format([[
    do
        local %s = (type(getgenv) == "function") and getgenv() or nil
        local %s = (%s and rawget(%s, "load"))
                or (%s and rawget(%s, "loadstring"))
                or rawget(_G, "load")
                or rawget(_G, "loadstring")
        if %s ~= nil and type(%s) == "function" then
            local %s = (type(isexecutorclosure) == "function") and isexecutorclosure(%s)
            local %s = (type(iscclosure)        == "function") and iscclosure(%s)
            if not %s and not %s then
                local %s = %q
                while true do local _ = %s end
            end
        end
    end
]],
        vGenv,
        vLoad,
        vGenv, vGenv, vGenv, vGenv,
        vLoad, vLoad,
        vIE, vLoad,
        vIN, vLoad,
        vIE, vIN,
        vKill, killStr, vKill
    )

    -- -----------------------------------------------------------------------
    -- 4. checkcaller() — pcall-wrapped
    -- -----------------------------------------------------------------------
    local callerBlock = ""
    if self.CheckCallerGuard then
        callerBlock = string.format([[
    do
        if type(checkcaller) == "function" then
            local ok, result = pcall(checkcaller)
            if ok and result == false then
                local %s = %q
                while true do local _ = %s end
            end
        end
    end
]], vKill, killStr, vKill)
    end

    -- -----------------------------------------------------------------------
    -- 5. Persistent monitor thread
    -- -----------------------------------------------------------------------
    local monitorBlock = ""
    if self.PersistentMonitor then
        monitorBlock = string.format([[
    do
        task.spawn(function()
            while true do
                task.wait(math.random(%d, %d))
                local %s = (type(getgenv) == "function") and getgenv() or nil
                local targets = {
                    (%s and rawget(%s, "load"))       or rawget(_G, "load"),
                    (%s and rawget(%s, "loadstring")) or rawget(_G, "loadstring"),
                }
                for _, %s in ipairs(targets) do
                    if %s ~= nil and type(%s) == "function" then
                        local %s = (type(isexecutorclosure) == "function") and isexecutorclosure(%s)
                        local %s = (type(iscclosure)        == "function") and iscclosure(%s)
                        if not %s and not %s then
                            local %s = %q
                            repeat local _ = %s until false
                        end
                    end
                end
            end
        end)
    end
]],
            minT, maxT,
            vGenv,
            vGenv, vGenv,
            vGenv, vGenv,
            vFn, vFn, vFn,
            vIE, vFn,
            vIN, vFn,
            vIE, vIN,
            vKill, killStr, vKill
        )
    end

    -- -----------------------------------------------------------------------
    -- Assemble the full guard inside one do-block
    -- -----------------------------------------------------------------------
    local code = "do\n"
        .. studioBlock
        .. globalsBlock
        .. integrityCheck
        .. callerBlock
        .. monitorBlock
        .. "end\n"

    -- -----------------------------------------------------------------------
    -- Parse and inject at position 1 in the AST
    -- -----------------------------------------------------------------------
    local parser = Parser:new({ LuaVersion = Enums.LuaVersion.Lua51 })
    local ok, parsed = pcall(function() return parser:parse(code) end)
    if not ok then
        logger:warn(string.format(
            "[ExecutorGuard] guard code failed to parse — step skipped. Reason: %s",
            tostring(parsed)
        ))
        return ast
    end

    for i = #parsed.body.statements, 1, -1 do
        local stat = parsed.body.statements[i]
        if stat.body and stat.body.scope then
            stat.body.scope:setParent(ast.body.scope)
        end
        table.insert(ast.body.statements, 1, stat)
    end

    logger:info(string.format(
        "[ExecutorGuard] injected %d guard block(s) at AST position 1.",
        #parsed.body.statements
    ))

    return ast
end

return ExecutorGuard
