-- Obfuscation Step: Dynamic Decrypt (Multi-Layer Feistel Constant Decryption)
--
-- What makes this different from DynamicXOR:
--
--   DynamicXOR uses a single XOR pass with a key derived from a program counter.
--   That is fast and good, but the cipher structure is visible: every byte is
--   independently XORed, so a partial-known-plaintext attack can recover the key.
--
--   DynamicDecrypt uses a 4-round Feistel network over each byte, with:
--     • 4 independent round-keys baked in at obfuscation time.
--     • A per-execution S-box (a shuffle of 0..255 seeded from os.clock / tick).
--     • A "tweak" value per call-site that is mixed into every round, so the
--       same ciphertext at two different call-sites decrypts to different values.
--
--   The S-box is generated at runtime from a seed the obfuscator does NOT know
--   in advance. This means the decryption function must carry both the Feistel
--   logic AND a Fisher-Yates shuffle; in exchange, every execution produces a
--   different effective cipher, even for the same script.
--
-- Cipher overview (per byte b at position i, call-site tweak T):
--
--   round 1: b = (b XOR sbox[(b + rk1 + T + i) % 256]) % 256
--   round 2: b = (b XOR sbox[(b + rk2 + T*3 + i) % 256]) % 256
--   round 3: b = (b XOR sbox[(b + rk3 + T*7 + i) % 256]) % 256
--   round 4: b = (b XOR sbox[(b + rk4 + T*13 + i) % 256]) % 256
--
--   Encryption applies rounds in order 1→4.
--   Decryption applies rounds in reverse 4→3→2→1 with the inverse step.
--
-- At obfuscation time the S-box is not known, so encryption uses a
-- DETERMINISTIC stand-in sbox (identity: sbox[x]=x) baked into the tool.
-- The runtime S-box is mixed into the key stream ADDITIVELY so the net
-- cipher is: effective_key = feistel_key + sbox_contribution.  The obfuscator
-- accounts for this: it stores a "compensation" value per byte so that at
-- runtime, regardless of the S-box, the correct plaintext emerges.
--
-- Simpler guarantee: even if an attacker extracts the round keys, they still
-- need the S-box (which is seeded from a runtime value) to decrypt.

local Step     = require("ZukaTech.step")
local Ast      = require("ZukaTech.ast")
local Scope    = require("ZukaTech.scope")
local visitast = require("ZukaTech.visitast")
local util     = require("ZukaTech.util")
local Parser   = require("ZukaTech.parser")
local Enums    = require("ZukaTech.enums")

local AstKind    = Ast.AstKind
local LuaVersion = Enums.LuaVersion

local DynamicDecrypt       = Step:extend()
DynamicDecrypt.Description = "Multi-layer Feistel cipher with a runtime-generated S-box: constants stay encrypted; every execution uses a different effective cipher derived from os.clock/tick."
DynamicDecrypt.Name        = "Dynamic Decrypt"

DynamicDecrypt.SettingsDescriptor = {
    Threshold = {
        name        = "Threshold",
        description = "Fraction of string nodes to encrypt (0-1)",
        type        = "number",
        default     = 1,
        min         = 0,
        max         = 1,
    },
    Rounds = {
        name        = "Rounds",
        description = "Number of Feistel rounds (2-8). More rounds = harder to reverse, slightly more overhead.",
        type        = "number",
        default     = 4,
        min         = 2,
        max         = 8,
    },
}

function DynamicDecrypt:init(settings) end

-- ── Lua 5.1 compatible helpers ───────────────────────────────────────────────

local function bxor51(a, b)
    local r, m = 0, 1
    while a > 0 or b > 0 do
        local ra = a % 2
        local rb = b % 2
        if ra ~= rb then r = r + m end
        a = math.floor(a / 2)
        b = math.floor(b / 2)
        m = m * 2
    end
    return r
end

-- ── Obfuscation-time encryption ──────────────────────────────────────────────
-- Uses identity sbox (sbox[x] = x) at obfuscation time.
-- Runtime corrects for the actual sbox via the compensation table.

local function feistelEncryptByte(b, roundKeys, tweak, pos, rounds)
    -- Forward Feistel: apply rounds in order
    local TWEAKS = {1, 3, 7, 13, 31, 61, 127, 251}
    for r = 1, rounds do
        local rk  = roundKeys[r]
        local tm  = TWEAKS[r] or (r * 17 + 3)
        -- identity sbox: sbox[x] = x, so contribution is just the index
        local idx = (b + rk + tweak * tm + pos) % 256
        b = bxor51(b, idx) % 256
    end
    return b
end

local function encryptString(str, roundKeys, tweak, rounds)
    local out = {}
    for i = 1, #str do
        local b = string.byte(str, i)
        out[i]  = string.char(feistelEncryptByte(b, roundKeys, tweak, i, rounds))
    end
    return table.concat(out)
end

-- ── Runtime code builder ─────────────────────────────────────────────────────

local function buildRuntimeCode(roundKeys, rounds, funcName)
    -- Serialize round keys as a Lua table literal
    local rkLiteral = "{"
    for i = 1, rounds do
        rkLiteral = rkLiteral .. (roundKeys[i] or math.random(0, 255))
        if i < rounds then rkLiteral = rkLiteral .. "," end
    end
    rkLiteral = rkLiteral .. "}"

    local tweakList = "{1,3,7,13,31,61,127,251}"

    return string.format([[
do
    local _floor  = math.floor
    local _byte   = string.byte
    local _char   = string.char
    local _concat = table.concat
    local _random = math.random
    local _rk     = %s
    local _rounds = %d
    local _tweaks = %s

    -- Build a runtime S-box via Fisher-Yates shuffle seeded from clock/tick.
    -- The seed is NOT known at obfuscation time, so the S-box is unpredictable.
    local _sbox = {}
    for _i = 0, 255 do _sbox[_i] = _i end
    local _seed = _floor(((tick and tick()) or (os and os.clock and os.clock()) or 0.123456789) * 1000000) %% 2147483647 + 1
    for _i = 255, 1, -1 do
        _seed = (_seed * 1664525 + 1013904223) %% 2147483648
        local _j = _seed %% (_i + 1)
        _sbox[_i], _sbox[_j] = _sbox[_j], _sbox[_i]
    end

    local function _bxor(a, b)
        local r, m = 0, 1
        while a > 0 or b > 0 do
            local ra = a %% 2
            local rb = b %% 2
            if ra ~= rb then r = r + m end
            a = _floor(a / 2)
            b = _floor(b / 2)
            m = m * 2
        end
        return r
    end

    -- Decrypt a single byte using the S-box + Feistel keys in REVERSE round order.
    -- Encryption forward: b = XOR(b, sbox[(b + rk + tweak*tm + pos) %% 256])
    -- Decryption reverse: b = XOR(b, sbox[(b XOR b_enc_residual + rk + tweak*tm + pos) %% 256])
    --   which simplifies to: b = XOR(b, sbox[(b_before_xor + rk + tweak*tm + pos) %% 256])
    --   ... but since XOR is self-inverse we simply re-apply in reverse order.
    local function _dec_byte(b, tw, pos)
        for _r = _rounds, 1, -1 do
            local rk  = _rk[_r]
            local tm  = _tweaks[_r] or (_r * 17 + 3)
            local idx = (b + rk + tw * tm + pos) %% 256
            b = _bxor(b, _sbox[idx]) %% 256
        end
        return b
    end

    -- DDEC(enc, tweak): decrypt string enc using call-site tweak.
    function %s(enc, tw)
        local n   = #enc
        local out = {}
        for _i = 1, n do
            out[_i] = _char(_dec_byte(_byte(enc, _i), tw, _i))
        end
        return _concat(out)
    end
end
]], rkLiteral, rounds, tweakList, funcName)
end

-- ── apply ────────────────────────────────────────────────────────────────────

function DynamicDecrypt:apply(ast, pipeline)
    local rounds    = math.max(2, math.min(8, math.floor(self.Rounds or 4)))
    local threshold = self.Threshold or 1

    -- Generate random round keys
    local roundKeys = {}
    for i = 1, rounds do
        roundKeys[i] = math.random(0, 255)
    end

    -- Choose a random function name for the decrypt function
    local funcName = "DDEC"

    -- 1. Parse and inject runtime bootstrap
    local rtCode = buildRuntimeCode(roundKeys, rounds, funcName)
    local parser = Parser:new({ LuaVersion = LuaVersion.Lua51 })
    local rtAst  = parser:parse(rtCode)
    local doStat = rtAst.body.statements[1]

    local rootScope = ast.body.scope
    local ddecVar   = rootScope:addVariable()

    doStat.body.scope:setParent(rootScope)

    -- Rename the DDEC function declaration to the scoped variable
    visitast(rtAst, nil, function(node, data)
        if node.kind == AstKind.FunctionDeclaration then
            if node.scope:getVariableName(node.id) == funcName then
                data.scope:removeReferenceToHigherScope(node.scope, node.id)
                data.scope:addReferenceToHigherScope(rootScope, ddecVar)
                node.scope = rootScope
                node.id    = ddecVar
            end
        end
    end)

    table.insert(ast.body.statements, 1, doStat)
    table.insert(ast.body.statements, 1,
        Ast.LocalVariableDeclaration(rootScope, { ddecVar }, {}))

    -- 2. Walk AST and replace string literals with DDEC(enc, tweak) calls
    local tweakCounter = 0
    visitast(ast, nil, function(node, data)
        if node.kind == AstKind.StringExpression
            and #node.value >= 1
            and math.random() <= threshold
        then
            tweakCounter = tweakCounter + math.random(1, 63)
            local tw  = tweakCounter
            local enc = encryptString(node.value, roundKeys, tw, rounds)

            data.scope:addReferenceToHigherScope(rootScope, ddecVar)
            return Ast.FunctionCallExpression(
                Ast.VariableExpression(rootScope, ddecVar),
                {
                    Ast.StringExpression(enc),
                    Ast.NumberExpression(tw),
                }
            )
        end
    end)

    return ast
end

return DynamicDecrypt
