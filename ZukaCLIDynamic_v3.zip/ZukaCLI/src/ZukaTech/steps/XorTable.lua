-- This Script is Part of the ZukaTech Obfuscator
--
-- XorTable.lua
--
-- Implements the "Calculated_Xor_Tbl" pattern observed in Luraph.

local Step          = require("ZukaTech.step")
local Ast           = require("ZukaTech.ast")
local Scope         = require("ZukaTech.scope")
local Parser        = require("ZukaTech.parser")
local Enums         = require("ZukaTech.enums")
local visitast      = require("ZukaTech.visitast")
local RandomStrings = require("ZukaTech.randomStrings")

local AstKind    = Ast.AstKind
local LuaVersion = Enums.LuaVersion

local XorTable       = Step:extend()
XorTable.Description = "Replaces bit32.bxor with a precomputed nibble-XOR lookup table (Luraph Calculated_Xor_Tbl pattern)."
XorTable.Name        = "XOR Table"

XorTable.SettingsDescriptor = {
    ShuffleTable = {
        name        = "ShuffleTable",
        description = "Shuffle the 16x16 base table row/column order via a permutation.",
        type        = "boolean",
        default     = true,
    },
    ReplaceBit32 = {
        name        = "ReplaceBit32",
        description = "Replace bit32.bxor calls in the AST with the injected table function.",
        type        = "boolean",
        default     = true,
    },
}

function XorTable:init(settings) end

-- ── helpers ──────────────────────────────────────────────────────────────────

local function makePermutation()
    local p = {}
    for i = 0, 15 do p[i+1] = i end
    for i = 16, 2, -1 do
        local j = math.random(1, i)
        p[i], p[j] = p[j], p[i]
    end
    local q = {}
    for i = 0, 15 do q[i] = p[i+1] end
    return q
end

local function buildNibbleTable(shuffle)
    local rowPerm = shuffle and makePermutation() or nil
    local colPerm = shuffle and makePermutation() or nil

    local tbl = {}
    for r = 0, 15 do
        local storeRow = rowPerm and rowPerm[r] or r
        tbl[storeRow] = tbl[storeRow] or {}
        for c = 0, 15 do
            local storeCol = colPerm and colPerm[c] or c
            local xval = 0
            local a, b, m2 = r, c, 1
            while a > 0 or b > 0 do
                if (a % 2) ~= (b % 2) then xval = xval + m2 end
                a = math.floor(a / 2)
                b = math.floor(b / 2)
                m2 = m2 * 2
            end
            tbl[storeRow][storeCol] = xval
        end
    end

    return tbl, rowPerm, colPerm
end

local function rowToLiteral(row)
    local parts = {}
    for c = 0, 15 do
        parts[c+1] = tostring(row[c])
    end
    return "[0] = " .. parts[1] .. ", " .. table.concat(parts, ", ", 2)
end

local function invPermLiteral(perm)
    if not perm then return nil end
    local inv = {}
    for orig = 0, 15 do
        local stored = perm[orig]
        inv[stored] = orig
    end
    local parts = {}
    for i = 0, 15 do
        parts[i+1] = tostring(inv[i])
    end
    return "[0] = " .. parts[1] .. ", " .. table.concat(parts, ", ", 2)
end

-- ── runtime code ──────────────────────────────────────────────────────────────

local function buildRuntimeCode(nibbleTbl, rowPerm, colPerm, fnName, tblName)
    local rowLiterals = {}
    for r = 0, 15 do
        rowLiterals[r+1] = string.format("        { %s }", rowToLiteral(nibbleTbl[r]))
    end
    local tblBody = table.concat(rowLiterals, ",\n")

    local invRowLit = invPermLiteral(rowPerm)
    local invColLit = invPermLiteral(colPerm)

    local invRowDecl = invRowLit and ("    local _ir = { " .. invRowLit .. " }\n") or ""
    local invColDecl = invColLit and ("    local _ic = { " .. invColLit .. " }\n") or ""
    local invRowUse  = invRowLit and "_ir[a16]" or "a16"
    local invColUse  = invColLit and "_ic[b16]" or "b16"

    -- FIX: The original __index used tbl[0] thinking it held the `a` value,
    -- but tbl[0] is just the XOR result for row 0. The lazy extension metatable
    -- needs the row value `a` passed in as the table key when setmetatable is
    -- called per-row. We restructure: each row sub-table gets its own metatable
    -- that closes over the row index `_r` so __index(tbl, b) can correctly
    -- compute XOR(_r, b) for any b beyond the precomputed 16 columns.
    local code = "do\n"
    code = code .. "    local _floor = math.floor\n"
    code = code .. "    local " .. tblName .. " = {\n" .. tblBody .. "\n    }\n"
    code = code .. invRowDecl
    code = code .. invColDecl

    -- Per-row metatables that close over the actual row index
    code = code .. "    for _r = 0, 15 do\n"
    code = code .. "        local _rowIdx = _r\n"
    code = code .. "        setmetatable(" .. tblName .. "[_r], {\n"
    code = code .. "            __index = function(tbl, b)\n"
    code = code .. "                local a_rem, b_rem, xor_res, mul = _rowIdx, b, 0, 1\n"
    code = code .. "                while a_rem > 0 or b_rem > 0 do\n"
    code = code .. "                    local ad = a_rem % 16\n"
    code = code .. "                    local bd = b_rem % 16\n"
    code = code .. "                    xor_res = xor_res + " .. tblName .. "[ad][bd] * mul\n"
    code = code .. "                    a_rem = (a_rem - ad) / 16\n"
    code = code .. "                    b_rem = (b_rem - bd) / 16\n"
    code = code .. "                    mul = mul * 16\n"
    code = code .. "                end\n"
    code = code .. "                local res = xor_res + (a_rem + b_rem) * mul\n"
    code = code .. "                tbl[b] = res\n"
    code = code .. "                return res\n"
    code = code .. "            end\n"
    code = code .. "        })\n"
    code = code .. "    end\n"

    -- Public bxor function
    code = code .. "    function " .. fnName .. "(a, b)\n"
    code = code .. "        if a == b then return 0 end\n"
    code = code .. "        local r, m = 0, 1\n"
    code = code .. "        local av, bv = a + 0, b + 0\n"
    code = code .. "        while av > 0 or bv > 0 do\n"
    code = code .. "            local a16 = av % 16\n"
    code = code .. "            local b16 = bv % 16\n"
    code = code .. "            r  = r + " .. tblName .. "[" .. invRowUse .. "][" .. invColUse .. "] * m\n"
    code = code .. "            av = _floor(av / 16)\n"
    code = code .. "            bv = _floor(bv / 16)\n"
    code = code .. "            m  = m * 16\n"
    code = code .. "        end\n"
    code = code .. "        return r\n"
    code = code .. "    end\n"
    code = code .. "end\n"

    return code
end

-- ── AST walk: replace bit32.bxor calls ───────────────────────────────────────

local function replaceBit32Bxor(ast, rootScope, bxorVarId)
    visitast(ast, nil, function(node, data)
        if node.kind ~= AstKind.FunctionCallExpression then return end
        local base = node.base
        if not base then return end
        if base.kind ~= AstKind.IndexExpression then return end
        local tblNode = base.base
        local keyNode = base.index
        if not tblNode or not keyNode then return end
        if tblNode.kind ~= AstKind.VariableExpression then return end
        if keyNode.kind ~= AstKind.StringExpression   then return end
        if keyNode.value ~= "bxor" then return end
        local name = tblNode.scope and tblNode.scope:getVariableName(tblNode.id)
        if name ~= "bit32" then return end

        data.scope:addReferenceToHigherScope(rootScope, bxorVarId)
        node.base = Ast.VariableExpression(rootScope, bxorVarId)
        return node
    end)
end

-- ── apply ─────────────────────────────────────────────────────────────────────

function XorTable:apply(ast, pipeline)
    local shuffle    = (self.ShuffleTable ~= false)
    local replaceBit = (self.ReplaceBit32 ~= false)

    local fnName  = "_bxor_" .. RandomStrings.randomString(6)
    local tblName = "_xtbl_" .. RandomStrings.randomString(6)

    local nibbleTbl, rowPerm, colPerm = buildNibbleTable(shuffle)
    local rtCode = buildRuntimeCode(nibbleTbl, rowPerm, colPerm, fnName, tblName)

    local parser = Parser:new({ LuaVersion = LuaVersion.Lua51 })
    local rtAst  = parser:parse(rtCode)
    local doStat = rtAst.body.statements[1]

    local rootScope = ast.body.scope
    local bxorVarId = rootScope:addVariable()

    doStat.body.scope:setParent(rootScope)

    visitast(rtAst, nil, function(node, data)
        if node.kind == AstKind.FunctionDeclaration then
            if node.scope and node.scope:getVariableName(node.id) == fnName then
                data.scope:removeReferenceToHigherScope(node.scope, node.id)
                data.scope:addReferenceToHigherScope(rootScope, bxorVarId)
                node.scope = rootScope
                node.id    = bxorVarId
            end
        end
    end)

    table.insert(ast.body.statements, 1, doStat)
    table.insert(ast.body.statements, 1,
        Ast.LocalVariableDeclaration(rootScope, { bxorVarId }, {}))

    if replaceBit then
        replaceBit32Bxor(ast, rootScope, bxorVarId)
    end

    return ast
end

return XorTable
