-- This Script is Part of the ZukaTech Obfuscator
--
-- BlobCompress.lua
--
-- Implements the LZW blob-compression technique from IronBrew2.

local Step   = require("ZukaTech.step")
local logger = require("logger")

local BlobCompress       = Step:extend()
BlobCompress.Description = "LZW-compresses the final output into a base-36 blob (IronBrew2 technique). Typically saves 30-40% on obfuscated output >= 2 KB."
BlobCompress.Name        = "Blob Compress"

BlobCompress.SettingsDescriptor = {
    MinInputBytes = {
        name        = "MinInputBytes",
        description = "Skip compression if input is smaller than this many bytes",
        type        = "number",
        default     = 900,
        min         = 0,
        max         = 1e9,
    },
    MinGainPct = {
        name        = "MinGainPct",
        description = "Skip compression unless output is at least this many percent smaller than input (0-100)",
        type        = "number",
        default     = 5,
        min         = 0,
        max         = 100,
    },
    ObfuscateBlob = {
        name        = "ObfuscateBlob",
        description = "Apply a random-key XOR pass to every byte of the compressed blob before storing it.",
        type        = "boolean",
        default     = false,
    },
}

function BlobCompress:init(settings) end

-- ── LZW compression ──────────────────────────────────────────────────────────

local CHARS36 = "0123456789abcdefghijklmnopqrstuvwxyz"

local function toBase36(n)
    if n == 0 then return "0" end
    local s = ""
    while n > 0 do
        local r = n % 36
        s = CHARS36:sub(r + 1, r + 1) .. s
        n = math.floor(n / 36)
    end
    return s
end

local function encodeCode(n)
    local s = toBase36(n)
    return toBase36(#s) .. s
end

local function lzwCompress(input)
    local dict     = {}
    local dictSize = 256
    for i = 0, 255 do
        dict[string.char(i)] = i
    end

    local w   = ""
    local out = {}

    for i = 1, #input do
        local c  = input:sub(i, i)
        local wc = w .. c
        if dict[wc] then
            w = wc
        else
            out[#out + 1] = encodeCode(dict[w])
            dict[wc] = dictSize
            dictSize  = dictSize + 1
            w = c
        end
    end
    if w ~= "" then
        out[#out + 1] = encodeCode(dict[w])
    end

    return table.concat(out)
end

-- ── Optional XOR pass on the blob ────────────────────────────────────────────

local function bxor51(a, b)
    local r, m = 0, 1
    while a > 0 or b > 0 do
        local ra, rb = a % 2, b % 2
        if ra ~= rb then r = r + m end
        a = math.floor(a / 2)
        b = math.floor(b / 2)
        m = m * 2
    end
    return r
end

local function xorBlob(blob, key)
    local out = {}
    for i = 1, #blob do
        out[i] = string.char(bxor51(blob:byte(i), key) % 256)
    end
    return table.concat(out)
end

-- ── Runtime code templates ────────────────────────────────────────────────────

-- FIX: while i<#b changed to while i<=#b — the original dropped the last token
-- causing silent corruption on every decompressed output.
local DECOMP_TEMPLATE = [[local function _D(b)local c,d,e,f,g="","",{},256,{}for h=0,255 do g[h]=string.char(h)end;local i=1;local function k()local l=tonumber(string.sub(b,i,i),36);i=i+1;local m=tonumber(string.sub(b,i,i+l-1),36);i=i+l;return m end;c=string.char(k());e[1]=c;while i<=#b do local n=k();if g[n]then d=g[n]else d=c..string.sub(c,1,1)end;g[f]=c..string.sub(d,1,1);e[#e+1],c,f=d,d,f+1 end;return table.concat(e)end;]]

local DECOMP_XOR_TEMPLATE = [[local function _D(b)local c,d,e,f,g="","",{},256,{}for h=0,255 do g[h]=string.char(h)end;local i=1;local function k()local l=tonumber(string.sub(b,i,i),36);i=i+1;local m=tonumber(string.sub(b,i,i+l-1),36);i=i+l;return m end;c=string.char(k());e[1]=c;while i<=#b do local n=k();if g[n]then d=g[n]else d=c..string.sub(c,1,1)end;g[f]=c..string.sub(d,1,1);e[#e+1],c,f=d,d,f+1 end;return table.concat(e)end;local function _bx(a,b)local r,m=0,1;while a>0 or b>0 do local ra,rb=a%%2,b%%2;if ra~=rb then r=r+m end;a=math.floor(a/2);b=math.floor(b/2);m=m*2 end;return r end;local function _XD(b,k)local o={}for i=1,#b do o[i]=string.char(_bx(string.byte(b,i),k)%%256)end;return table.concat(o)end;]]

-- ── compressSource ────────────────────────────────────────────────────────────

function BlobCompress:compressSource(source)
    local minBytes  = self.MinInputBytes or 900
    local minGain   = (self.MinGainPct   or 5) / 100
    local xorPass   = (self.ObfuscateBlob == true)

    if #source < minBytes then
        logger:info(string.format(
            "[BlobCompress] Skipped: input %d bytes < MinInputBytes %d",
            #source, minBytes))
        return source
    end

    local blob = lzwCompress(source)

    local xorKey = 0
    if xorPass then
        xorKey = math.random(1, 127)
        blob   = xorBlob(blob, xorKey)
    end

    local function longStr(s)
        local level = 0
        while s:find("]" .. string.rep("=", level) .. "]", 1, true) do
            level = level + 1
        end
        local eq = string.rep("=", level)
        return "[" .. eq .. "[" .. s .. "]" .. eq .. "]"
    end

    local blobLit = longStr(blob)
    local decompHeader, execLine

    if xorPass then
        decompHeader = DECOMP_XOR_TEMPLATE
        execLine = string.format(
            "(loadstring or load)(_D(_XD(%s,%d)))()",
            blobLit, xorKey
        )
    else
        decompHeader = DECOMP_TEMPLATE
        execLine = string.format(
            "(loadstring or load)(_D(%s))()",
            blobLit
        )
    end

    local output = decompHeader .. execLine

    local gain = 1 - (#output / #source)
    if gain < minGain then
        logger:info(string.format(
            "[BlobCompress] Skipped: gain %.1f%% < MinGainPct %.1f%%",
            gain * 100, minGain * 100))
        return source
    end

    logger:info(string.format(
        "[BlobCompress] %d -> %d bytes (%.1f%% of input, saved %.1f%%)",
        #source, #output,
        (#output / #source) * 100,
        gain * 100))

    return output
end

-- ── Step interface ────────────────────────────────────────────────────────────

function BlobCompress:apply(ast, pipeline)
    if pipeline._blobCompressStep then
        logger:warn("[BlobCompress] Multiple BlobCompress steps detected; only the last one will run.")
    end
    if pipeline._compressorStep then
        logger:info("[BlobCompress] Note: Compressor step also present. Compressor runs first, then BlobCompress.")
    end
    pipeline._blobCompressStep = self
    return ast
end

return BlobCompress
