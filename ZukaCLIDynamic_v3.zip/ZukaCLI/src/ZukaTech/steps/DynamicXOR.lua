-- Obfuscation Step: Dynamic XOR Constant Decryption
--
-- Tier 1 Upgrade #1: Instead of decoding the constant pool once at startup,
-- each constant remains encrypted. At access time the cipher key is derived
-- from the current "program counter" (a runtime counter incremented each
-- opcode dispatch), so a hook that dumps after the init loop sees nothing.
--
-- Implementation strategy:
--   • Wraps every string literal in a DXOR(encBytes, idx) call where idx is
--     a per-call unique integer (the "instruction seed").
--   • The runtime DXOR function XORs each byte with:
--       key_byte = base_key XOR ((inst_seed * PRIME + byte_pos) % 251)
--     This is cheap, Lua-5.1-compatible, and changes per call-site.
--   • A global "vm_pc" counter (localised) is incremented on every DXOR call
--     so the effective key also shifts with execution order.

local Step       = require("ZukaTech.step")
local Ast        = require("ZukaTech.ast")
local Scope      = require("ZukaTech.scope")
local visitast   = require("ZukaTech.visitast")
local util       = require("ZukaTech.util")
local Parser     = require("ZukaTech.parser")
local Enums      = require("ZukaTech.enums")

local AstKind    = Ast.AstKind
local LuaVersion = Enums.LuaVersion

local DynamicXOR       = Step:extend()
DynamicXOR.Description = "Per-call-site dynamic XOR: constants stay encrypted; key changes each access via a VM program-counter state variable."
DynamicXOR.Name        = "Dynamic XOR"

DynamicXOR.SettingsDescriptor = {
    Treshold = {
        name        = "Treshold",
        description = "Fraction of string nodes to encrypt (0–1)",
        type        = "number",
        default     = 1,
        min         = 0,
        max         = 1,
    },
}

function DynamicXOR:init(settings) end

-- ── helpers ──────────────────────────────────────────────────────────────────

local function bxor51(a, b)
    -- Lua 5.1 compatible bitwise XOR (no bit32 / ~ operator)
    local r, m = 0, 1
    while a > 0 or b > 0 do
        local ra = a % 2
        local rb = b % 2
        if ra ~= rb then r = r + m end
        a = math.floor(a / 2)
        b = math.floor(b / 2)
        m = m * 2
    end
    return r
end

-- PRIME is chosen per-compile from a pool of large primes with good avalanche
-- properties. None of these are the FNV prime (16777619) so static searches
-- for known crypto constants come up empty.
local PRIME_POOL = {
    15485863, 32452843, 49979687, 67867967, 86028121,
    104395301, 122949823, 141650963, 160481183, 179424673,
    198491317, 217645177, 236887699, 256203161, 275604541,
}
-- VPC_MOD and VPC_MUL replace hardcoded 65521/1000003 so the pc step
-- function doesn't match any known pattern either.
local VPC_MOD_POOL  = {65521, 65519, 65497, 65479, 65449, 65437, 65423}
local VPC_MUL_POOL  = {1000003, 999983, 1000033, 999979, 1000037, 999961}
local VPC_ADD_POOL  = {7, 11, 13, 17, 19, 23, 29}
-- KEY_MOD replaces hardcoded 251 (the byte-range mod used in key derivation)
local KEY_MOD_POOL  = {251, 241, 239, 233, 229, 227}

-- These are picked fresh in apply() so each compilation uses different values.
-- Forward-declared here so encryptString can close over them.
local _PRIME, _VPC_MOD, _VPC_MUL, _VPC_ADD, _KEY_MOD

-- encryptString mirrors the RUNTIME key derivation without the vpc component.
-- Each call-site has a unique instSeed so two sites with the same plaintext
-- produce different ciphertext. The runtime DXOR mixes in _vpc for additional
-- per-execution-point variance.
local function encryptString(str, instSeed, baseKey)
    local out = {}
    for i = 1, #str do
        local b      = string.byte(str, i)
        local kbyte  = bxor51(baseKey, (instSeed * _PRIME + i) % _KEY_MOD)
        out[i]       = string.char(bxor51(b, kbyte) % 256)
    end
    return table.concat(out)
end

-- ── runtime code template ────────────────────────────────────────────────────
--
-- FIX: Previously _vpc was incremented but never fed into the actual XOR key,
-- only into `ckey` which was computed but then discarded (cache was keyed on
-- `inst` alone, bypassing `ckey` entirely).
--
-- Now:
--   • The XOR key byte mixes in _vpc so the same encrypted bytes at two
--     different call-sites decode to DIFFERENT plaintext.
--   • The cache is deliberately REMOVED. Caching by inst would let a dumper
--     read all decrypted strings by scanning cache after one full run.
--     The decryption is fast enough that no-cache is fine.
--   • _vpc is seeded from os.clock()/tick() if available so it is not 0
--     at startup, adding runtime entropy that can't be predicted statically.

local function buildRuntimeCode(baseKey, prime, vpc_mod, vpc_mul, vpc_add, key_mod)
    return string.format([[
do
    local _floor  = math.floor
    local _byte   = string.byte
    local _char   = string.char
    local _concat = table.concat
    local _bkey   = %d
    local _prime  = %d
    local _vmod   = %d
    local _vmul   = %d
    local _vadd   = %d
    local _kmod   = %d

    -- Seed _vpc from a runtime value so static analysis can't predict it.
    -- Falls back to 1 if neither tick nor os.clock is available.
    local _tick   = (tick and tick()) or (os and os.clock and os.clock()) or 0
    local _vpc    = (_floor(_tick * 1000) %% _vmod) + 1

    local function _bxor(a, b)
        local r, m = 0, 1
        while a > 0 or b > 0 do
            local ra = a %% 2
            local rb = b %% 2
            if ra ~= rb then r = r + m end
            a = _floor(a / 2)
            b = _floor(b / 2)
            m = m * 2
        end
        return r
    end

    -- Advance the program counter each decrypt call so the effective
    -- key shifts with execution order. _vmul/_vadd are unique per compile.
    local function _advance()
        _vpc = (_vpc * _vmul + _vadd) %% _vmod + 1
        return _vpc
    end

    -- DXOR: decrypt enc using inst (call-site seed) mixed with current _vpc.
    -- No cache — every call re-derives the key from live state. A getgc()
    -- dump after startup only ever sees ciphertext in the constant pool.
    function DXOR(enc, inst)
        local pc    = _advance()
        local eseed = (inst * _prime + pc) %% _vmod
        local n     = #enc
        local out   = {}
        for i = 1, n do
            local eb    = _byte(enc, i)
            local kbyte = _bxor(_bkey, (eseed * _prime + i) %% _kmod)
            out[i]      = _char(_bxor(eb, kbyte) %% 256)
        end
        return _concat(out)
    end
end
]], baseKey, prime, vpc_mod, vpc_mul, vpc_add, key_mod)
end

-- ── apply ────────────────────────────────────────────────────────────────────

function DynamicXOR:apply(ast, pipeline)
    -- Pick all cipher constants fresh for this compilation run.
    local PRIME   = PRIME_POOL[math.random(#PRIME_POOL)]
    local VPC_MOD = VPC_MOD_POOL[math.random(#VPC_MOD_POOL)]
    local VPC_MUL = VPC_MUL_POOL[math.random(#VPC_MUL_POOL)]
    local VPC_ADD = VPC_ADD_POOL[math.random(#VPC_ADD_POOL)]
    local KEY_MOD = KEY_MOD_POOL[math.random(#KEY_MOD_POOL)]

    -- Wire the module-level upvalues so encryptString uses EXACTLY the same
    -- constants that will be emitted into the runtime DXOR decryptor.
    _PRIME   = PRIME
    _VPC_MOD = VPC_MOD
    _VPC_MUL = VPC_MUL
    _VPC_ADD = VPC_ADD
    _KEY_MOD = KEY_MOD

    local baseKey  = math.random(1, 127)
    local instSeed = 0   -- monotonically increasing per string

    -- 1. Parse and inject runtime code
    local rtCode  = buildRuntimeCode(baseKey, PRIME, VPC_MOD, VPC_MUL, VPC_ADD, KEY_MOD)
    local parser  = Parser:new({ LuaVersion = LuaVersion.Lua51 })
    local rtAst   = parser:parse(rtCode)
    local doStat  = rtAst.body.statements[1]

    local rootScope = ast.body.scope
    local dxorVar   = rootScope:addVariable()

    doStat.body.scope:setParent(rootScope)

    visitast(rtAst, nil, function(node, data)
        if node.kind == AstKind.FunctionDeclaration then
            if node.scope:getVariableName(node.id) == "DXOR" then
                data.scope:removeReferenceToHigherScope(node.scope, node.id)
                data.scope:addReferenceToHigherScope(rootScope, dxorVar)
                node.scope = rootScope
                node.id    = dxorVar
            end
        end
    end)

    table.insert(ast.body.statements, 1, doStat)
    table.insert(ast.body.statements, 1,
        Ast.LocalVariableDeclaration(rootScope, { dxorVar }, {}))

    -- 2. Walk AST and replace string literals with DXOR(enc, seed) calls
    visitast(ast, nil, function(node, data)
        if node.kind == AstKind.StringExpression and math.random() <= self.Treshold then
            instSeed = instSeed + math.random(1, 31)   -- non-sequential gaps
            local enc  = encryptString(node.value, instSeed, baseKey)
            local seed = instSeed

            data.scope:addReferenceToHigherScope(rootScope, dxorVar)
            return Ast.FunctionCallExpression(
                Ast.VariableExpression(rootScope, dxorVar),
                {
                    Ast.StringExpression(enc),
                    Ast.NumberExpression(seed),
                }
            )
        end
    end)

    return ast
end

return DynamicXOR
