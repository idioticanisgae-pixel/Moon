-- steps/ZukaZalgo.lua
-- ZukaZalgo Post-Processor Step — by Zuka
--
-- Sprays Unicode combining characters over the entire obfuscated output.
-- Replicates the MoonSec v5 visual obfuscation technique.
--
-- Every character in the output gets stacked diacritical marks:
-- accents, tildes, dots, arrowheads, hooks, rings — completely
-- unreadable to humans while Lua parses it identically.
--
-- Add to your preset Steps table:
--   { Name = "ZukaZalgo", Settings = { Density = 0.85, MaxMarks = 8 } }
--
-- Settings:
--   Density  (0.0–1.0) — chance any given char gets marks. Default 0.85
--   MaxMarks (int)     — max combining marks per char.   Default 8
--   Strings  (bool)    — also zalgo string literal contents. Default false
--                        (keep false unless you want to break string values)

local util = require("ZukaTech.util")

-- Full combining mark set (same pool MoonSec uses)
local MARKS = {
    "\xCC\x80", "\xCC\x81", "\xCC\x82", "\xCC\x83", "\xCC\x84",
    "\xCC\x86", "\xCC\x87", "\xCC\x88", "\xCC\x8A", "\xCC\x8B",
    "\xCC\x8C", "\xCC\x8F", "\xCC\x91", "\xCC\x93", "\xCC\x94",
    "\xCC\x97", "\xCC\x98", "\xCC\x99", "\xCC\x9B", "\xCC\x9F",
    "\xCC\xA0", "\xCC\xA3", "\xCC\xA4", "\xCC\xA5", "\xCC\xA6",
    "\xCC\xA7", "\xCC\xA8", "\xCC\xAD", "\xCC\xAE", "\xCC\xB0",
    "\xCC\xB1", "\xCC\xB2", "\xCC\xB4", "\xCC\xB8", "\xCD\x85",
    "\xCD\x86", "\xCD\x8A", "\xCD\x8B", "\xCD\x8C", "\xCD\x91",
    "\xCD\x94", "\xCD\x95", "\xCD\x98", "\xCD\x9A", "\xCD\x9C",
    "\xCD\x9E", "\xCD\xA0", "\xCD\xA1", "\xCD\xA3", "\xCD\xA5",
    "\xCD\xA9", "\xCD\xAF",
    -- Extra heavy marks for density (the ones MoonSec uses most)
    "\xD2\x89", -- COMBINING CYRILLIC MILLIONS SIGN (dramatic swirl)
    "\xCC\xAB", -- COMBINING LATIN SMALL LETTER U
    "\xCD\x96", -- COMBINING RIGHT ARROWHEAD AND UP ARROWHEAD BELOW
    "\xCD\x99", -- COMBINING WIDE INVERTED BRIDGE BELOW
    "\xCC\xB3", -- COMBINING DOUBLE LOW LINE
}

local DEFAULT_DENSITY  = 0.85
local DEFAULT_MAXMARKS = 8

-- Characters that should NEVER get combining marks
-- (structural Lua syntax where marks would break parsing)
local SKIP = {
    ["\n"] = true, ["\r"] = true, ["\t"] = true,
    ["\""] = true, ["'"]  = true, ["["]  = true,
    ["]"]  = true, ["\\"] = true,
}

local function shouldSkip(ch)
    return SKIP[ch] == true
end

local function processSource(source, settings)
    local density  = (settings and settings.Density)  or DEFAULT_DENSITY
    local maxMarks = (settings and settings.MaxMarks)  or DEFAULT_MAXMARKS
    local doStr    = (settings and settings.Strings)   or false

    math.randomseed(os.time())
    util.shuffle(MARKS)

    local result   = {}
    local inString = false
    local strChar  = nil
    local i        = 1
    local len      = #source

    while i <= len do
        local ch = source:sub(i, i)

        -- Track string boundaries so we don't corrupt string contents
        -- unless Strings setting is enabled
        if not inString and (ch == "\"" or ch == "'") then
            inString = true
            strChar  = ch
            table.insert(result, ch)
            i = i + 1
        elseif inString then
            if ch == "\\" then
                -- escaped char — pass both through untouched
                table.insert(result, ch)
                table.insert(result, source:sub(i + 1, i + 1))
                i = i + 2
            elseif ch == strChar then
                inString = false
                strChar  = nil
                table.insert(result, ch)
                i = i + 1
            else
                if doStr and not shouldSkip(ch) and math.random() < density then
                    local count = math.random(1, maxMarks)
                    table.insert(result, ch)
                    for _ = 1, count do
                        table.insert(result, MARKS[math.random(#MARKS)])
                    end
                else
                    table.insert(result, ch)
                end
                i = i + 1
            end
        else
            -- Normal code — apply zalgo to everything except skip chars
            if not shouldSkip(ch) and math.random() < density then
                local count = math.random(1, maxMarks)
                table.insert(result, ch)
                for _ = 1, count do
                    table.insert(result, MARKS[math.random(#MARKS)])
                end
            else
                table.insert(result, ch)
            end
            i = i + 1
        end
    end

    return table.concat(result)
end

-- ── STEP INTERFACE ────────────────────────────────────────────────────────────
-- Matches the ZukaTech pipeline step format used by DynamicXOR and others.

local ZukaZalgoStep = {}
ZukaZalgoStep.__index = ZukaZalgoStep

-- Required by pipeline step system
ZukaZalgoStep.Name        = "ZukaZalgo"
ZukaZalgoStep.Description = "Sprays Unicode combining characters over the final output (runs after BlobCompress)."

function ZukaZalgoStep.new(settings)
    return setmetatable({ settings = settings or {} }, ZukaZalgoStep)
end

-- Called during the AST pipeline phase — registers as a post-unparse pass
-- so Zalgo runs AFTER BlobCompress, not before it.
-- Previously Zalgo ran here and BlobCompress then compressed away all the marks.
function ZukaZalgoStep:apply(ast, pipeline)
    if pipeline._zalgoStep then
        -- warn but allow override (last wins, same as BlobCompress behaviour)
        if require and pcall(require, "logger") then
            local logger = require("logger")
            logger:warn("[ZukaZalgo] Multiple ZukaZalgo steps — only the last will run.")
        end
    end
    pipeline._zalgoStep = self
    return ast  -- AST unchanged; real work happens in post-pass
end

-- Called by pipeline:apply() after BlobCompress
function ZukaZalgoStep:process(source)
    return processSource(source, self.settings)
end

-- Some pipeline versions call via a flat function instead of OOP.
-- The registry needs the class itself (has .new, :apply, .Name).
-- Direct process() call still works via the class method.
ZukaZalgoStep.process = function(self_or_source, settings_or_nil)
    -- Handle both ZukaZalgoStep:process(source) and ZukaZalgo.process(source, settings)
    if type(self_or_source) == "string" then
        return processSource(self_or_source, settings_or_nil)
    end
    return processSource(settings_or_nil, self_or_source.settings)
end

return ZukaZalgoStep
