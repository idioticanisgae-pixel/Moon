-- steps/CrewmateFormat.lua
-- ZukaTech Obfuscation Step: CrewmateFormat
--
-- Post-unparse formatting pass.
-- Reshapes the entire obfuscated output so that when viewed in a text editor,
-- the indentation of each line traces the silhouette of an Among Us crewmate.
--
-- The code executes IDENTICALLY — all formatting is pure leading whitespace.
-- Lua ignores leading spaces completely. The shape is cosmetic intimidation.
--
-- Technique:
--   1. Strip all existing leading/trailing whitespace from every line.
--   2. Drop empty lines.
--   3. For the TOP section (head, visor, body, backpack):
--      Each line is padded to a fixed left indent. Lines that fall in the
--      "body" band are also right-padded with spaces then trimmed to the
--      band width so they don't overflow the silhouette.
--   4. For the LEGS section: each line is split roughly in half and placed
--      into the left-leg column and right-leg column with a gap between.
--   5. Remaining overflow lines are appended normally (feet / below).
--
-- Settings:
--   Scale    (number, default 1) — multiply all indent/width values. Use 2
--            for a giant crewmate on wide monitors.
--   Strict   (boolean, default false) — if true, lines that would exceed
--            their band width are hard-truncated (breaks code — debug only).
--
-- Add to your preset LAST (after BlobCompress, before ZukaZalgo):
--   { Name = "CrewmateFormat", Settings = { Scale = 1 } }

local Step   = require("ZukaTech.step")
local logger = require("logger")

-- ── Crewmate silhouette profile ───────────────────────────────────────────────
--
-- BODY_BANDS: { left_pad, content_width }
--   left_pad      = spaces before the code line
--   content_width = max characters of code on that line (0 = unlimited)
--
-- LEG_BANDS: { left_leg_pad, leg_width, right_leg_pad, leg_width }
--   Two separate columns. Each "line" of code is split into two halves.
--
-- All values are at Scale = 1. The step multiplies by Scale at runtime.

local BODY_BANDS = {
    -- HEAD dome
    { 34, 6  },
    { 28, 18 },
    { 22, 30 },
    { 17, 40 },
    { 14, 46 },
    { 12, 50 },
    -- VISOR area (the narrower band in the middle = visor dark region)
    { 11, 52 },
    { 14, 46 },
    { 11, 52 },
    -- BODY upper
    {  9, 56 },
    {  8, 58 },
    {  8, 58 },
    -- BACKPACK bump (right side extends further — content_width is wider)
    {  8, 64 },
    {  8, 64 },
    {  8, 64 },
    -- BODY lower
    {  8, 58 },
    {  8, 58 },
    --  LOWER TAPER
    {  9, 56 },
    { 11, 50 },
}

local LEG_BANDS = {
    -- { left_leg_indent, left_leg_width, right_leg_indent, right_leg_width }
    {  9, 18, 36, 18 },
    {  9, 18, 36, 18 },
    {  9, 18, 36, 18 },
    {  9, 18, 36, 18 },
    -- FEET (slightly wider, flared)
    {  8, 20, 35, 20 },
    {  8, 20, 35, 20 },
}

local DEFAULT_SCALE  = 1
local DEFAULT_STRICT = false

-- ── Helpers ───────────────────────────────────────────────────────────────────

local function spaces(n)
    if n <= 0 then return "" end
    return string.rep(" ", n)
end

-- Split source into non-empty trimmed lines.
-- If the source has very few newlines (dense single-line output from other
-- obfuscation passes), we also split on semicolons so the formatter has
-- enough "lines" to trace the crewmate silhouette.
local function getLines(source)
    local lines = {}

    local function pushLine(s)
        local trimmed = s:match("^%s*(.-)%s*$")
        if trimmed and #trimmed > 0 then
            lines[#lines + 1] = trimmed
        end
    end

    -- Count newlines
    local _, newlineCount = source:gsub("\n", "")

    if newlineCount < 10 then
        -- Dense output: split on newlines first, then semicolons inside each chunk
        for chunk in (source .. "\n"):gmatch("([^\n]*)\n") do
            -- split chunk on semicolons that are NOT inside strings
            -- simple heuristic: split on '; ' or ';' followed by a keyword/local
            local subchunks = {}
            local buf = ""
            local inStr = false
            local strChar = ""
            local i = 1
            while i <= #chunk do
                local c = chunk:sub(i, i)
                if inStr then
                    buf = buf .. c
                    if c == "\\" then
                        -- escape: consume next char too
                        i = i + 1
                        if i <= #chunk then buf = buf .. chunk:sub(i, i) end
                    elseif c == strChar then
                        inStr = false
                    end
                else
                    if c == '"' or c == "'" then
                        inStr = true
                        strChar = c
                        buf = buf .. c
                    elseif c == ";" then
                        pushLine(buf)
                        buf = ""
                    else
                        buf = buf .. c
                    end
                end
                i = i + 1
            end
            if #buf > 0 then pushLine(buf) end
        end
    else
        -- Normal multi-line output
        for line in (source .. "\n"):gmatch("([^\n]*)\n") do
            pushLine(line)
        end
    end

    return lines
end

-- Format a single body band line:
-- left_pad spaces + code (hard-limited to width if strict, otherwise free)
local function formatBodyLine(code, left_pad, width, strict)
    local pad = spaces(left_pad)
    if strict and #code > width then
        code = code:sub(1, width)
    end
    return pad .. code
end

-- Format a leg band line: split code roughly in half, place each half
-- in its respective column, separated by a gap of spaces.
local function formatLegLine(code, ll_pad, ll_width, rl_pad, rl_width, strict)
    local mid   = math.floor(#code / 2)
    local left  = code:sub(1, mid)
    local right = code:sub(mid + 1)

    if strict then
        if #left  > ll_width then left  = left:sub(1, ll_width)  end
        if #right > rl_width then right = right:sub(1, rl_width) end
    end

    -- Build: [ll_pad][left_code][gap][right_code]
    local gap_start = ll_pad + ll_width
    local gap_size  = rl_pad - gap_start
    if gap_size < 1 then gap_size = 1 end

    return spaces(ll_pad) .. left .. spaces(gap_size) .. right
end

-- ── Core formatter ────────────────────────────────────────────────────────────

local function processSource(source, scale, strict)
    scale  = scale  or DEFAULT_SCALE
    strict = strict or DEFAULT_STRICT

    local lines    = getLines(source)
    local result   = {}
    local lineIdx  = 1
    local totalLines = #lines

    -- Scale the profile
    local bodyBands = {}
    for _, b in ipairs(BODY_BANDS) do
        bodyBands[#bodyBands + 1] = {
            math.floor(b[1] * scale),
            math.floor(b[2] * scale),
        }
    end

    local legBands = {}
    for _, b in ipairs(LEG_BANDS) do
        legBands[#legBands + 1] = {
            math.floor(b[1] * scale),
            math.floor(b[2] * scale),
            math.floor(b[3] * scale),
            math.floor(b[4] * scale),
        }
    end

    -- BODY section
    for _, band in ipairs(bodyBands) do
        if lineIdx > totalLines then break end
        local lpad  = band[1]
        local width = band[2]
        result[#result + 1] = formatBodyLine(lines[lineIdx], lpad, width, strict)
        lineIdx = lineIdx + 1
    end

    -- LEG section — each band consumes 2 source lines (one per leg column)
    for _, band in ipairs(legBands) do
        if lineIdx > totalLines then break end
        local ll_pad   = band[1]
        local ll_width = band[2]
        local rl_pad   = band[3]
        local rl_width = band[4]

        -- Consume up to 2 lines and merge them into one visual leg row
        local lineA = lines[lineIdx] or ""
        lineIdx = lineIdx + 1
        local lineB = lines[lineIdx] or ""
        lineIdx = lineIdx + 1

        -- Combine both lines into a single "code blob" for this leg row
        -- Use a semicolon joiner so both statements stay valid on one line
        local combined
        if #lineA > 0 and #lineB > 0 then
            combined = lineA .. " " .. lineB
        else
            combined = lineA .. lineB
        end

        result[#result + 1] = formatLegLine(
            combined, ll_pad, ll_width, rl_pad, rl_width, strict
        )
    end

    -- OVERFLOW — any remaining lines go out normally, cycling through
    -- a gentle taper indent so the "feet" don't just fall off a cliff
    local taperIndents = { 8, 9, 10, 11, 12, 13, 14, 16, 18, 20 }
    local taperIdx     = 1
    while lineIdx <= totalLines do
        local indent = taperIndents[taperIdx] or 20
        taperIdx     = (taperIdx % #taperIndents) + 1
        result[#result + 1] = spaces(indent) .. lines[lineIdx]
        lineIdx = lineIdx + 1
    end

    return table.concat(result, "\n")
end

-- ── Step interface ─────────────────────────────────────────────────────────────

local CrewmateFormat = Step:extend()
CrewmateFormat.Name        = "CrewmateFormat"
CrewmateFormat.Description = "Post-unparse pass: reshapes the entire output into the Among Us crewmate silhouette using pure indentation. Code executes identically."

CrewmateFormat.SettingsDescriptor = {
    Scale = {
        name        = "Scale",
        description = "Multiply all indent/width values. 1 = normal, 2 = giant crewmate.",
        type        = "number",
        default     = DEFAULT_SCALE,
        min         = 1,
        max         = 4,
    },
    Strict = {
        name        = "Strict",
        description = "Hard-truncate lines that exceed their band width (breaks code — debug only).",
        type        = "boolean",
        default     = DEFAULT_STRICT,
    },
}

function CrewmateFormat:init(settings)
    self.Scale  = self.Scale  or DEFAULT_SCALE
    self.Strict = self.Strict or DEFAULT_STRICT
end

-- Register as a post-unparse pass.
-- Best placed AFTER VariableRenamer/BytecodeEncoder but BEFORE ZukaZalgo,
-- so Zalgo's combining marks stack on top of the crewmate shape.
function CrewmateFormat:apply(ast, pipeline)
    if pipeline._crewmateFormatStep then
        logger:warn("[CrewmateFormat] Multiple CrewmateFormat steps — last one wins.")
    end
    pipeline._crewmateFormatStep = self
    return ast
end

-- Called by the pipeline post-unparse hook.
function CrewmateFormat:process(source)
    logger:info("[CrewmateFormat] Shaping output into crewmate silhouette...")
    local result = processSource(source, self.Scale, self.Strict)
    logger:info("[CrewmateFormat] sus.")
    return result
end

return CrewmateFormat